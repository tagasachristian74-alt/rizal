// RIZAL: THE FINAL JOURNEY — Quiz Battle
// Question bank built strictly from "RIZAL REVIEWER.pdf" (Trial & Martyrdom at Bagumbayan)
// type: 'mc' (Multiple Choice A/B/C/D), 'tf' (True or False), 'id' (Identification)
// c = category, q = question, o = options, a = correct index (for mc/tf) or accepted answers array (for id)

const CATEGORIES = {
  all: 'All Topics (Full Reviewer)',
  journey: 'The Final Journey',
  trial: 'Trial & Investigation',
  martyrdom: 'Martyrdom at Bagumbayan',
  adios: 'Mi Ultimo Adios',
};

const QUESTIONS = [
  // ─── THE FINAL JOURNEY (MC) ──────────────────────────────────────────
  { type: 'mc', c: 'journey', q: 'On September 2, 1896, Rizal left Manila for Spain aboard which steamer?', o: ['Isla de Panay', 'Castilla', 'Colón', 'Caridad'], a: 0 },
  { type: 'mc', c: 'journey', q: "Who approved Rizal's request to serve as a military doctor in Cuba?", o: ['Gov. Camilo de Polavieja', 'Gov. Ramón Blanco', 'Eulogio Despujol', 'Nicolás de la Peña'], a: 1 },
  { type: 'mc', c: 'journey', q: 'Before going to Cuba, Rizal had to travel first to…', o: ['Hong Kong', 'Singapore', 'Spain', 'Mexico'], a: 2 },
  { type: 'mc', c: 'journey', q: 'After his arrest, Rizal was jailed in which city before being sent back to Manila?', o: ['Madrid', 'Barcelona', 'Valencia', 'Seville'], a: 1 },
  { type: 'mc', c: 'journey', q: 'Rizal spent the last months of his life in which Philippine fortress?', o: ['Fort Santiago', 'Cuartel de España', 'Montjuïc Castle', 'Bagumbayan field'], a: 0 },
  { type: 'mc', c: 'journey', q: 'The first Katipunan rescue attempt was conveyed to Rizal by which emissary?', o: ['Emilio Jacinto', 'Andrés Bonifacio', 'Dr. Pío Valenzuela', 'José Dizon'], a: 2 },
  { type: 'mc', c: 'journey', q: 'In that first attempt, where did the Katipunan plan to secretly take Rizal?', o: ['Japan', 'Borneo', 'Hong Kong', 'The United States'], a: 0 },
  { type: 'mc', c: 'journey', q: 'In August 1896, Jacinto, Bonifacio and other Katipuneros disguised themselves as sailors of which boat to approach Rizal aboard the Castilla?', o: ['Isla de Panay', 'Colón', 'Caridad', 'Elcano'], a: 2 },
  { type: 'mc', c: 'journey', q: 'Why did Rizal refuse the Katipunan’s rescue attempts?', o: ['He was too sick to travel', 'He would not break his promise to the Spanish authorities and did not want to be blamed as the instigator', 'He did not trust Bonifacio', 'He wanted to surrender in Cuba'], a: 1 },
  { type: 'mc', c: 'journey', q: 'The night before his final journey, Rizal wrote a letter to his mother saying his task required strength and dedication. Who was she?', o: ['Trinidad Rizal', 'Narcisa Rizal', 'Josephine Bracken', 'Doña Teodora Alonzo'], a: 3 },
  { type: 'mc', c: 'journey', q: 'Who captained the Isla de Panay and received the telegraphic order to arrest and confine Rizal?', o: ['Capt. Rafael Domínguez', 'Capt. A. Alemany', 'Lt. José Togores Arjona', 'Eulogio Despujol'], a: 1 },
  { type: 'mc', c: 'journey', q: 'Which two London-based friends of Rizal tried to find a lawyer in Singapore to rescue him?', o: ['Antonio Ma. Regidor and Sixto López', 'Juan del Fresno and Eloy Moure', 'Francisco Olive and Rafael Domínguez', 'Pío Valenzuela and José Dizon'], a: 0 },
  { type: 'mc', c: 'journey', q: 'Which lawyer received the telegraphs to rescue Rizal and issued a writ of habeas corpus for the steamer Colón?', o: ['Atty. Enrique de Alcocer', 'Lt. Luis Taviel de Andrade', 'Atty. Hugh Fort', 'Capt. Rafael Domínguez'], a: 2 },
  { type: 'mc', c: 'journey', q: 'What happened to the Singapore judge’s ruling on the habeas corpus request?', o: ['It was granted', 'It was denied', 'It was postponed indefinitely', 'It was quietly approved'], a: 1 },
  { type: 'mc', c: 'journey', q: 'On November 3, 1896, Rizal arrived in Manila and was brought to…', o: ['Fort Santiago', 'Cuartel de España', 'Bagumbayan Field', 'Montjuïc Castle'], a: 0 },

  // ─── TRIAL & INVESTIGATION (MC) ──────────────────────────────────────
  { type: 'mc', c: 'trial', q: 'When did the preliminary investigation against Rizal begin?', o: ['November 20, 1896', 'October 6, 1896', 'December 11, 1896', 'November 3, 1896'], a: 0 },
  { type: 'mc', c: 'trial', q: 'How long did Rizal’s preliminary investigation last?', o: ['Two days', 'Five days', 'One week', 'Ten days'], a: 1 },
  { type: 'mc', c: 'trial', q: 'Who conducted the preliminary investigation as Judge Advocate?', o: ['Capt. Rafael Domínguez', 'Col. Francisco Olive', 'Don Nicolás de la Peña', 'Lt. Enrique de Alcocer'], a: 1 },
  { type: 'mc', c: 'trial', q: 'How many exhibits made up the documentary evidence against Rizal?', o: ['Twelve', 'Fifteen', 'Twenty-four', 'One hundred'], a: 1 },
  { type: 'mc', c: 'trial', q: 'Colonel Olive endorsed the evidences to Governor Blanco, who designated as Judge Advocate…', o: ['Capt. Rafael Domínguez', 'Lt. Enrique de Alcocer', 'Lt. Luis Taviel de Andrade', 'Lt. Col. José Togores Arjona'], a: 0 },
  { type: 'mc', c: 'trial', q: 'Domínguez transmitted the records to the Judge Advocate General for an opinion. Who held that office?', o: ['Don Nicolás de la Peña', 'Gov. Camilo de Polavieja', 'Archbishop Bernardino Nozaleda', 'Fr. Pío Pi'], a: 0 },
  { type: 'mc', c: 'trial', q: 'Peña recommended, among others, that Rizal’s properties be attached and that as indemnity he pay…', o: ['100,000 pesos', '500,000 pesos', 'One million pesos', '325–3,250 pesetas'], a: 2 },
  { type: 'mc', c: 'trial', q: 'Rizal could only choose his defense counsel from a list of how many army officers provided by the authorities?', o: ['25', '50', '100', '125'], a: 2 },
  { type: 'mc', c: 'trial', q: 'Rizal chose as his defense counsel…', o: ['Lt. Enrique de Alcocer', 'Capt. Rafael Domínguez', 'Lt. José Taviel de Andrade', 'Lt. Luis Taviel de Andrade'], a: 3 },
  { type: 'mc', c: 'trial', q: 'Why did Rizal feel connected to Lt. Luis Taviel de Andrade?', o: ['He was his Ateneo teacher', 'He was the brother of Lt. José Taviel de Andrade, Rizal’s bodyguard in Calamba in 1887', 'He was his law school classmate', 'He was a friend from London'], a: 1 },
  { type: 'mc', c: 'trial', q: 'On December 11, 1896, the charges were read. Rizal replied that he did not question the court’s jurisdiction and that…', o: ['he admitted everything', 'he had nothing to amend and nothing to admit', 'he wanted a civilian lawyer', 'he renounced La Liga Filipina'], a: 1 },
  { type: 'mc', c: 'trial', q: 'Rizal’s case was endorsed to Blanco’s successor, who had the authority to order a court-martial. Who was he?', o: ['Eulogio Despujol', 'Gov. Ramón Blanco', 'Gen. Marcelo de Azcárraga', 'Gov. Camilo de Polavieja'], a: 3 },
  { type: 'mc', c: 'trial', q: 'Rizal’s controversial December 15 Manifesto denounced bloody struggle and promoted what as the best means to acquire independence?', o: ['Armed revolt', 'Education and industry', 'Foreign intervention', 'General strikes'], a: 1 },
  { type: 'mc', c: 'trial', q: 'What did Judge Advocate General de la Peña request Governor Polavieja to do about the Manifesto?', o: ['Publish it widely', 'Translate it into Tagalog', 'Prohibit its publication', 'Send it to Spain for review'], a: 2 },
  { type: 'mc', c: 'trial', q: 'Rizal’s court-martial was held at…', o: ['Cuartel de España', 'Fort Santiago', 'Bagumbayan Field', 'Montjuïc Castle'], a: 0 },
  { type: 'mc', c: 'trial', q: 'The court that tried Rizal was composed of seven military officers headed by…', o: ['Lt. Enrique de Alcocer', 'Lt. Col. José Togores Arjona', 'Col. Francisco Olive', 'Capt. Ricardo Muñoz Arias'], a: 1 },
  { type: 'mc', c: 'trial', q: 'The three crimes Rizal was accused of were rebellion, sedition, and…', o: ['treason', 'espionage', 'illegal association', 'desertion'], a: 2 },
  { type: 'mc', c: 'trial', q: 'Who was the prosecuting attorney who urged the court that Rizal be punished with death?', o: ['Lt. Enrique de Alcocer', 'Lt. Luis Taviel de Andrade', 'Atty. Hugh Fort', 'Capt. Santiago Izquierdo Osorio'], a: 0 },
  { type: 'mc', c: 'trial', q: 'When did Rizal’s court-martial commence?', o: ['December 11, 1896, 8 AM', 'December 26, 1896, 8 AM', 'December 29, 1896, 6 AM', 'December 30, 1896, 7 AM'], a: 1 },
  { type: 'mc', c: 'trial', q: 'Which of these was NOT one of Rizal’s 12 defense points?', o: ['Valenzuela testified Rizal was against rebellion', 'La Liga Filipina was a civic, not a revolutionary, association', 'If guilty, he could have escaped while in Singapore', 'He personally authored the Katipunan’s revolutionary by-laws'], a: 3 },
  { type: 'mc', c: 'trial', q: 'Rizal’s speech at whose house allegedly inspired the revolution — a claim he wanted to confront the witnesses about?', o: ['Doroteo Ongjunco’s house', 'Andrés Bonifacio’s house', 'Pío Valenzuela’s house', 'José Dizon’s house'], a: 0 },
  { type: 'mc', c: 'trial', q: 'Why did Rizal say the Katipunan sent an unfamiliar emissary to him in Dapitan?', o: ['He was under house arrest', 'He was too ill to meet anyone', 'His friends knew he never advocated violence', 'He had been excommunicated'], a: 2 },
  { type: 'mc', c: 'trial', q: 'Rizal was sentenced to be shot by musketry until death at 7 o’clock in the morning of December 30, 1896 at…', o: ['Fort Santiago', 'Bagumbayan', 'Cuartel de España', 'Luneta Hill'], a: 1 },

  // ─── MARTYRDOM AT BAGUMBAYAN (MC) ────────────────────────────────────
  { type: 'mc', c: 'martyrdom', q: 'At 6 AM of December 29, 1896, who read before Rizal the official notice of his execution scheduled the next day?', o: ['Capt. Rafael Domínguez', 'Fr. Vicente Balaguer', 'Lt. Luis Taviel de Andrade', 'Col. Francisco Olive'], a: 0 },
  { type: 'mc', c: 'martyrdom', q: 'Where did Rizal spend his last hours on earth after the notice was read?', o: ['In his dark cell only', 'In the prison chapel', 'In the captain’s quarters', 'In Cuartel de España'], a: 1 },
  { type: 'mc', c: 'martyrdom', q: 'Fr. Luis Viza came with Fr. Saderra Mata, bringing the image of the Sacred Heart of Jesus that Rizal made at…', o: ['UST', 'Ateneo Municipal', 'La Concordia College', 'Colegio de San Juan de Letran'], a: 1 },
  { type: 'mc', c: 'martyrdom', q: 'Which priest had earlier prophesied that Rizal would lose his head for writing the Noli Me Tangere — prompting Rizal’s ironic “congratulations”?', o: ['Fr. José Villaclara', 'Fr. Luis Viza', 'Fr. Federico Faura', 'Fr. Estanislao March'], a: 2 },
  { type: 'mc', c: 'martyrdom', q: 'Which sister received the alcohol cooking stove from Rizal, with a last piece hidden inside?', o: ['Narcisa', 'Trinidad', 'Olympia', 'Saturnina'], a: 1 },
  { type: 'mc', c: 'martyrdom', q: 'At 10 PM, Rizal rejected the retraction letter prepared by Archbishop Nozaleda because…', o: ['it praised Masonry', 'it was in Latin', 'it insulted his mother', 'it was too long'], a: 3 },
  { type: 'mc', c: 'martyrdom', q: 'Rizal finally signed a shorter retraction renouncing the Mason movement at 11:30 PM — a draft prepared by…', o: ['Fr. Vicente Balaguer', 'Fr. Pío Pi', 'Archbishop Bernardino Nozaleda', 'Fr. José Villaclara'], a: 1 },
  { type: 'mc', c: 'martyrdom', q: 'Who witnessed the signing of the retraction letter?', o: ['Juan del Fresno and Eloy Moure', 'Fr. Villaclara and Fr. March', 'Capt. Domínguez and Lt. Andrade', 'Fr. Viza and Fr. Faura'], a: 0 },
  { type: 'mc', c: 'martyrdom', q: 'After his third confession in the chapel, Rizal read which book?', o: ['Noli Me Tangere', 'El Filibusterismo', 'Imitación de Cristo', 'Sucesos de las Islas Filipinas'], a: 2 },
  { type: 'mc', c: 'martyrdom', q: '3:30 AM, December 30, 1896 — who led the mass at which Rizal received Communion?', o: ['Fr. Federico Faura', 'Fr. Vicente Balaguer', 'Fr. José Villaclara', 'Fr. Luis Viza'], a: 1 },
  { type: 'mc', c: 'martyrdom', q: 'Accompanied by his sister Narcisa, Josephine Bracken arrived — and the couple was canonically blessed as husband and wife by…', o: ['Fr. Miguel Saderra Mata', 'Fr. Estanislao March', 'Fr. Vicente Balaguer', 'Archbishop Nozaleda'], a: 2 },
  { type: 'mc', c: 'martyrdom', q: 'What wedding gift did Rizal give to Josephine Bracken?', o: ['A copy of Noli Me Tangere', 'Imitación de Cristo', 'His rosary', 'A gold remembrance coin'], a: 1 },
  { type: 'mc', c: 'martyrdom', q: 'For the march to Bagumbayan, Rizal wore…', o: ['a white linen suit and straw hat', 'a military uniform', 'his Dapitan farmer’s clothes', 'black suit, black necktie, black hat, black shoes, white vest'], a: 3 },
  { type: 'mc', c: 'martyrdom', q: 'Rizal was tied behind from elbow to elbow, but he kept in his right hand…', o: ['a small crucifix', 'a rosary, held until his final breath', 'the Mi Ultimo Adios', 'a pocket watch'], a: 1 },
  { type: 'mc', c: 'martyrdom', q: 'At Bagumbayan, Rizal requested to face the firing squad — the captain of the squad instead ordered…', o: ['a blindfold', 'a kneeling position', 'a back shot', 'a head shot standing'], a: 2 },
  { type: 'mc', c: 'martyrdom', q: 'Which physician was amazed that Rizal’s pulse rate was normal before the execution?', o: ['Dr. Felipe Ruiz Castillo', 'Dr. Antonio Ma. Regidor', 'Dr. Pío Valenzuela', 'Dr. Sixto López'], a: 0 },
  { type: 'mc', c: 'martyrdom', q: 'At what precise time did Rizal die on December 30, 1896?', o: ['6:30 in the morning', '7:00 in the morning', '7:03 in the morning', '8:00 in the morning'], a: 2 },
  { type: 'mc', c: 'martyrdom', q: 'After the volley, Rizal fell to the ground…', o: ['facing the firing squad directly', 'face toward the blue sky, his head slightly inclined toward the rising sun in the east', 'to his right side, gripping his rosary', 'to his left side, murmuring a prayer'], a: 1 },
  { type: 'mc', c: 'martyrdom', q: 'As Rizal fell, the crowd of Spaniards shouted…', o: ['“Viva España, viva Rizal!”', '“Mabuhay ang Pilipinas!”', '“Long live Spain! Death to traitors!”', '“Silencio! Que muera el traidor!”'], a: 2 },
  { type: 'mc', c: 'martyrdom', q: 'Whom did Rizal NOT write a final letter to on the eve of his execution?', o: ['His parents', 'Ferdinand Blumentritt', 'Paciano', 'Gov. Camilo de Polavieja'], a: 3 },

  // ─── MI ULTIMO ADIOS (MC) ────────────────────────────────────────────
  { type: 'mc', c: 'adios', q: 'Mi Ultimo Adios was written on the eve of Rizal’s execution — when?', o: ['December 26, 1896', 'December 29, 1896', 'December 30, 1896', 'December 11, 1896'], a: 1 },
  { type: 'mc', c: 'adios', q: 'Mi Ultimo Adios is considered…', o: ['a priceless gem of Philippine literature', 'a banned subversive pamphlet', 'a translation of Imitación de Cristo', 'a private letter to Blumentritt'], a: 0 },
  { type: 'mc', c: 'adios', q: 'How did Rizal pass the poem out of the chapel?', o: ['Inside a prayer book', 'Inside an alcohol cooking stove given to his sister', 'Inside a folded black hat', 'Whispered to Fr. Balaguer'], a: 1 },
  { type: 'mc', c: 'adios', q: 'The poem was originally untitled. Who entitled it “Mi Ultimo Adios” and published it in La Independencia on September 25, 1898?', o: ['Mariano Dacanay', 'Vicente Balaguer', 'Federico Faura', 'Bernardino Nozaleda'], a: 0 },
  { type: 'mc', c: 'adios', q: 'La Independencia, which first published the poem, was the newspaper of…', o: ['Antonio Luna', 'Apolinario Mabini', 'Marcelo H. del Pilar', 'Graciano López Jaena'], a: 0 },
  { type: 'mc', c: 'adios', q: 'How many stanzas does Mi Ultimo Adios have?', o: ['12', '14', '10', '16'], a: 1 },
  { type: 'mc', c: 'adios', q: 'Mi Ultimo Adios has been translated into about how many languages and dialects?', o: ['12', '20', '40', '60'], a: 2 },
  { type: 'mc', c: 'adios', q: 'The 1st stanza of Mi Ultimo Adios expresses…', o: ['his sacrifice for, and farewell to, his motherland', 'his fear of death', 'his anger at the Spanish friars', 'his farewell to his family alone'], a: 0 },
  { type: 'mc', c: 'adios', q: 'Which stanza presents his vision of a free and developed Philippines?', o: ['2nd stanza', '4th stanza', '7th stanza', '11th stanza'], a: 1 },
  { type: 'mc', c: 'adios', q: 'Which stanza urges the country to offer prayers for him and for his rest in God?', o: ['6th stanza', '8th stanza', '10th stanza', '13th stanza'], a: 1 },
  { type: 'mc', c: 'adios', q: 'Which stanzas say that though the dead are forgotten, his spirit will continue to live on?', o: ['10th–12th stanzas', '13th–14th stanzas', '1st–2nd stanzas', '7th–8th stanzas'], a: 0 },
  { type: 'mc', c: 'adios', q: 'In the 13th stanza, Rizal discusses heaven — a place where there is no slave nor oppressor, and only…', o: ['eternal silence', 'one Almighty Creator', 'the Filipino nation reborn', 'freedom from all tyrants'], a: 1 },
  { type: 'mc', c: 'adios', q: 'The 14th and final stanza declares that death is…', o: ['the ultimate enemy', 'eternal punishment', 'vengeance delayed', 'rest — all people die'], a: 3 },
  { type: 'mc', c: 'adios', q: '“Huling Paalam” / “My Last Farewell” is the Filipino title of which poem?', o: ['A La Juventud Filipina', 'Mi Ultimo Adios', 'Kundiman', 'Sa Aking mga Kabata'], a: 1 },

  // ─── TRUE OR FALSE (TF) ──────────────────────────────────────────────
  { type: 'tf', c: 'journey', q: 'TRUE OR FALSE: Rizal accepted the Katipunan’s rescue attempt to escape to Japan.', o: ['True', 'False'], a: 1 },
  { type: 'tf', c: 'journey', q: 'TRUE OR FALSE: The judge in Singapore granted Atty. Hugh Fort’s request for a writ of habeas corpus.', o: ['True', 'False'], a: 1 },
  { type: 'tf', c: 'trial', q: 'TRUE OR FALSE: Rizal was allowed to choose a civilian lawyer to defend him in the court-martial.', o: ['True', 'False'], a: 1 },
  { type: 'tf', c: 'trial', q: 'TRUE OR FALSE: Rizal’s court-martial was a fair trial with full due process and confrontation of witnesses.', o: ['True', 'False'], a: 1 },
  { type: 'tf', c: 'martyrdom', q: 'TRUE OR FALSE: Rizal’s pulse rate was normal right before his execution, surprising Dr. Felipe Ruiz Castillo.', o: ['True', 'False'], a: 0 },
  { type: 'tf', c: 'martyrdom', q: 'TRUE OR FALSE: The captain of the firing squad granted Rizal’s request to be shot facing the squad.', o: ['True', 'False'], a: 1 },
  { type: 'tf', c: 'adios', q: 'TRUE OR FALSE: Rizal’s final poem already had the title "Mi Ultimo Adios" when Trinidad found it inside the alcohol stove.', o: ['True', 'False'], a: 1 },
  { type: 'tf', c: 'adios', q: 'TRUE OR FALSE: Mi Ultimo Adios has 14 stanzas and has been translated into around 40 languages.', o: ['True', 'False'], a: 0 },

  // ─── IDENTIFICATION (ID) ─────────────────────────────────────────────
  { type: 'id', c: 'journey', q: 'IDENTIFICATION: Name the Philippine fortress where Rizal was imprisoned for the last months of his life.', a: ['Fort Santiago', 'Fuerte de Santiago'] },
  { type: 'id', c: 'trial', q: 'IDENTIFICATION: Who was the Spanish army lieutenant chosen by Rizal as his defense counsel?', a: ['Luis Taviel de Andrade', 'Lt. Luis Taviel de Andrade', 'Taviel de Andrade', 'Andrade'] },
  { type: 'id', c: 'trial', q: 'IDENTIFICATION: Name the military building where Rizal’s court-martial took place on December 26, 1896.', a: ['Cuartel de España', 'Cuartel de Espana'] },
  { type: 'id', c: 'martyrdom', q: 'IDENTIFICATION: Name the field in Manila where José Rizal was executed on December 30, 1896.', a: ['Bagumbayan', 'Bagumbayan Field'] },
  { type: 'id', c: 'martyrdom', q: 'IDENTIFICATION: Which sister of Rizal received the alcohol cooking stove containing his final poem?', a: ['Trinidad', 'Trinidad Rizal'] },
  { type: 'id', c: 'adios', q: 'IDENTIFICATION: What is the famous Spanish title given to Rizal’s last poem ("My Last Farewell")?', a: ['Mi Ultimo Adios', 'Mi Último Adiós'] },
];

module.exports = { QUESTIONS, CATEGORIES };
