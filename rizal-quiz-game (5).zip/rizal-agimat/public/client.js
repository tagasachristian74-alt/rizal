/* ═══════════════════════════════════════════════════════════════════
   RIZAL: THE FINAL JOURNEY — Quiz Battle · client
   ═══════════════════════════════════════════════════════════════════ */
'use strict';

const socket = io({ transports: ['websocket', 'polling'] });

/* ───────── helpers ───────── */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const escapeHtml = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[c]));
const uuid = () => (crypto.randomUUID ? crypto.randomUUID() : 'id-' + Math.random().toString(36).slice(2) + Date.now().toString(36));

const PROFILE_KEY = 'rizal.profile.v1';
const ROOM_KEY = 'rizal.room.v1';

const loadProfile = () => {
  try {
    const p = JSON.parse(localStorage.getItem(PROFILE_KEY));
    if (p && p.playerId) return { playerId: p.playerId, name: p.name || 'Rizalista', avatar: p.avatar || '🪶' };
  } catch (_) {}
  return { playerId: uuid(), name: 'Rizalista', avatar: '🪶' };
};
const saveProfile = () => localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
const saveRoomSession = (code) => sessionStorage.setItem(ROOM_KEY, JSON.stringify({ code, playerId: profile.playerId }));
const getRoomSession = () => { try { return JSON.parse(sessionStorage.getItem(ROOM_KEY)); } catch { return null; } };
const clearRoomSession = () => sessionStorage.removeItem(ROOM_KEY);

let profile = loadProfile();
let adminPin = sessionStorage.getItem('rizal.adminPin') || '';
let adminAction = null; // 'host' | 'board'
let currentScreen = 'home';
let room = null;
let selectedMode = 'classic';
let selectedCount = 50;
let hasAnswered = false;
let lastAck = null;
let questionDeadline = 0;
let questionDurationMs = 15000;
let timerRAF = null;
let lastTick = null;
let lastQuestionIndex = 0;
let lastTotalQuestions = 0;
let currentQType = 'mc';
let confettiRAF = null;

/* ───────── ambient golden embers ───────── */
(function initAmbient() {
  const canvas = $('#ambientCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
  resize();
  window.addEventListener('resize', resize);
  const embers = Array.from({ length: 32 }, () => ({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    r: 1 + Math.random() * 2.2,
    vy: -0.25 - Math.random() * 0.45,
    vx: (Math.random() - 0.5) * 0.25,
    a: 0.2 + Math.random() * 0.5,
  }));
  const frame = () => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (const e of embers) {
      e.y += e.vy; e.x += e.vx;
      if (e.y < -10) { e.y = canvas.height + 10; e.x = Math.random() * canvas.width; }
      ctx.beginPath();
      ctx.arc(e.x, e.y, e.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(232, 193, 90, ${e.a})`;
      ctx.fill();
    }
    requestAnimationFrame(frame);
  };
  requestAnimationFrame(frame);
})();

/* ───────── screens ───────── */
const SCREENS = ['home', 'host', 'join', 'lobby', 'game', 'practice', 'podium', 'leaderboard'];
function showScreen(name) {
  currentScreen = name;
  for (const s of SCREENS) {
    const el = $('#screen-' + s);
    if (el) el.classList.toggle('active', s === name);
  }
  document.body.classList.toggle('bg-bagumbayan', name === 'podium');
  document.body.classList.toggle('bg-portrait', name !== 'podium');
  window.scrollTo(0, 0);
}

const toastEl = $('#toast');
let toastTimer = null;
function toast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove('show'), 3600);
}

/* ───────── audio ───────── */
const AudioFX = (() => {
  let ctx = null;
  let muted = false;
  const ac = () => ctx || (ctx = new (window.AudioContext || window.webkitAudioContext)());
  function tone(freq, dur = 0.15, type = 'sine', when = 0, vol = 0.22) {
    if (muted) return;
    try {
      const a = ac(); if (a.state === 'suspended') a.resume();
      const o = a.createOscillator(); const g = a.createGain();
      o.type = type; o.frequency.value = freq;
      o.connect(g); g.connect(a.destination);
      const t = a.currentTime + when;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(vol, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.start(t); o.stop(t + dur + 0.05);
    } catch (_) {}
  }
  return {
    click: () => tone(1250, 0.03, 'square', 0, 0.05),
    lock: () => { tone(660, 0.09, 'triangle', 0, 0.22); tone(990, 0.09, 'triangle', 0.08, 0.18); },
    correct: () => { tone(523.25, 0.14, 'sine', 0); tone(659.25, 0.14, 'sine', 0.09); tone(784, 0.26, 'sine', 0.18); },
    wrong: () => { tone(220, 0.24, 'sawtooth', 0, 0.16); tone(155, 0.32, 'sawtooth', 0.13, 0.16); },
    tick: () => tone(920, 0.05, 'square', 0, 0.07),
    reveal: () => tone(392, 0.16, 'triangle', 0, 0.2),
    countdown: () => tone(440, 0.1, 'sine', 0, 0.2),
    go: () => tone(880, 0.3, 'sine', 0, 0.26),
    fanfare: () => [523.25, 659.25, 784, 1046.5].forEach((f, i) => tone(f, 0.3, 'triangle', i * 0.17, 0.22)),
    toggleMute: () => { muted = !muted; return muted; },
  };
})();

/* ───────── profile UI ───────── */
const AVATARS = ['🪶', '🎓', '📜', '⚖️', '🇵🇭', '🕊️', '📚', '🔥', '✊', '🌟'];
const avatarGrid = $('#avatarGrid');
const avatarPreview = $('#avatarPreview');
const inputName = $('#inputName');
const lobbyNameInput = $('#lobbyNameInput');

function renderAvatarGrid() {
  avatarGrid.innerHTML = '';
  for (const a of AVATARS) {
    const b = document.createElement('button');
    b.type = 'button';
    b.textContent = a;
    b.setAttribute('role', 'radio');
    b.setAttribute('aria-checked', a === profile.avatar ? 'true' : 'false');
    b.classList.toggle('selected', a === profile.avatar);
    b.addEventListener('click', () => {
      profile.avatar = a; saveProfile(); AudioFX.click();
      avatarPreview.textContent = a;
      renderAvatarGrid();
      socket.emit('updateProfile', { name: profile.name, avatar: profile.avatar });
    });
    avatarGrid.appendChild(b);
  }
  avatarPreview.textContent = profile.avatar;
}

function setName(value, source) {
  const v = String(value).slice(0, 16);
  profile.name = v;
  if (source !== inputName) inputName.value = v;
  if (source !== lobbyNameInput) lobbyNameInput.value = v;
  saveProfile();
  socket.emit('updateProfile', { name: v.trim() || 'Rizalista', avatar: profile.avatar });
}
inputName.addEventListener('input', e => setName(e.target.value, inputName));
lobbyNameInput.addEventListener('input', e => setName(e.target.value, lobbyNameInput));

function refreshMyStats() {
  socket.emit('getLeaderboard', { playerId: profile.playerId }, (res) => {
    if (!res) return;
    const me = (res.entries || []).find(e => e.id === profile.playerId);
    const you = res.you || (me ? { totalPoints: me.totalPoints, wins: me.wins, gamesPlayed: me.gamesPlayed, bestScore: me.bestScore } : null);
    $('#myStatBest').textContent = you ? you.bestScore.toLocaleString() : '0';
    $('#myStatWins').textContent = you ? you.wins.toLocaleString() : '0';
    $('#myStatGames').textContent = you ? you.gamesPlayed.toLocaleString() : '0';
  });
}

/* ───────── Admin PIN Gate ───────── */
function requireAdmin(action) {
  adminAction = action;
  if (adminPin) {
    socket.emit('adminVerify', { pin: adminPin }, (res) => {
      if (res && res.ok) onAdminUnlocked();
      else { adminPin = ''; openPinModal(); }
    });
  } else {
    openPinModal();
  }
}
function openPinModal() {
  $('#pinError').textContent = '';
  $('#inputAdminPin').value = '';
  $('#pinModal').hidden = false;
  setTimeout(() => $('#inputAdminPin').focus(), 60);
}
function onAdminUnlocked() {
  $('#pinModal').hidden = true;
  if (adminAction === 'host') { renderModeCards(); showScreen('host'); }
  else if (adminAction === 'board') { openLeaderboard(true); }
}
$('#btnClosePin').addEventListener('click', () => { $('#pinModal').hidden = true; });
$('#inputAdminPin').addEventListener('keydown', e => { if (e.key === 'Enter') $('#btnConfirmPin').click(); });
$('#btnConfirmPin').addEventListener('click', () => {
  const pin = $('#inputAdminPin').value.trim();
  socket.emit('adminVerify', { pin }, (res) => {
    if (res && res.ok) {
      adminPin = pin;
      sessionStorage.setItem('rizal.adminPin', pin);
      onAdminUnlocked();
    } else {
      $('#pinError').textContent = 'Incorrect Admin PIN.';
    }
  });
});

/* ───────── mode cards (host setup) ───────── */
const MODES = [
  { id: 'classic', icon: '⚔️', title: 'CLASSIC BATTLE', desc: 'Simultaneous A/B/C/D, True/False & Identification. Speed earns bonus points.' },
  { id: 'survival', icon: '💀', title: 'SURVIVAL', desc: 'One wrong answer eliminates you! Last fighter standing wins.' },
  { id: 'blitz', icon: '⚡', title: 'BLITZ RUSH', desc: '10 seconds per question, bigger speed bonus, high adrenaline.' },
];
const modeCards = $('#modeCards');
function renderModeCards() {
  modeCards.innerHTML = '';
  for (const m of MODES) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'mode-card' + (selectedMode === m.id ? ' selected' : '');
    b.innerHTML = `<div class="mode-icon">${m.icon}</div><div><h3>${m.title}</h3><p>${escapeHtml(m.desc)}</p></div>`;
    b.addEventListener('click', () => { selectedMode = m.id; AudioFX.click(); renderModeCards(); });
    modeCards.appendChild(b);
  }
}
$$('#segCount button').forEach(b => b.addEventListener('click', () => {
  selectedCount = b.dataset.count === 'all' ? 'all' : Number(b.dataset.count);
  $$('#segCount button').forEach(x => x.classList.toggle('active', x === b));
  AudioFX.click();
}));

/* ───────── navigation ───────── */
$('#tabStudent').addEventListener('click', () => {
  AudioFX.click();
  $('#tabStudent').classList.add('active');
  $('#tabAdmin').classList.remove('active');
  $('#studentLoginPane').hidden = false;
  $('#adminLoginPane').hidden = true;
});
$('#tabAdmin').addEventListener('click', () => {
  AudioFX.click();
  $('#tabAdmin').classList.add('active');
  $('#tabStudent').classList.remove('active');
  $('#adminLoginPane').hidden = false;
  $('#studentLoginPane').hidden = true;
});
$('#btnAdminBoardHome').addEventListener('click', () => { AudioFX.click(); requireAdmin('board'); });

$('#btnCreate').addEventListener('click', () => { AudioFX.click(); requireAdmin('host'); });
$('#btnJoin').addEventListener('click', () => { AudioFX.click(); $('#joinError').textContent = ''; showScreen('join'); setTimeout(() => $('#inputRoomCode').focus(), 80); });
$('#btnPractice').addEventListener('click', () => { AudioFX.click(); startPractice(); });
$('#btnSoundTop').addEventListener('click', () => {
  const m = AudioFX.toggleMute();
  $('#btnSoundTop').textContent = m ? '🔇 Muted' : '🔊 Sound';
});
$('#btnLeaderboardTop').addEventListener('click', () => { AudioFX.click(); openLeaderboard(false); });
$('#btnAdminBoard').addEventListener('click', () => { AudioFX.click(); requireAdmin('board'); });
$('#btnHowTop').addEventListener('click', () => { AudioFX.click(); $('#howModal').hidden = false; });
$('#btnCloseHow').addEventListener('click', () => { $('#howModal').hidden = true; });
$('#howModal').addEventListener('click', e => { if (e.target.id === 'howModal') $('#howModal').hidden = true; });
$('#btnHomeLogo').addEventListener('click', () => showScreen('home'));
$$('.back-link[data-go="home"]').forEach(b => b.addEventListener('click', () => showScreen('home')));
$('#btnExitHome').addEventListener('click', () => { clearRoomSession(); showScreen('home'); });
$('#btnToLeaderboard').addEventListener('click', () => { AudioFX.click(); openLeaderboard(false); });
$('#btnBoardBack').addEventListener('click', () => showScreen(room && room.state === 'podium' ? 'podium' : 'home'));

/* ───────── create room ───────── */
$('#btnConfirmCreate').addEventListener('click', () => {
  AudioFX.go();
  const btn = $('#btnConfirmCreate');
  btn.disabled = true;
  socket.emit('createRoom', {
    adminPin,
    name: profile.name, avatar: profile.avatar, playerId: profile.playerId,
    mode: selectedMode, questionCount: selectedCount, category: $('#selectCategory').value,
  }, (res) => {
    btn.disabled = false;
    if (!res || !res.ok) return toast(res && res.message ? res.message : 'Could not create room.');
    room = res.state;
    saveRoomSession(res.code);
    lobbyNameInput.value = profile.name;
    showScreen('lobby');
    renderLobby(room);
  });
});

/* ───────── join room ───────── */
const roomCodeInput = $('#inputRoomCode');
roomCodeInput.addEventListener('input', () => { roomCodeInput.value = roomCodeInput.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4); });
roomCodeInput.addEventListener('keydown', e => { if (e.key === 'Enter') $('#btnConfirmJoin').click(); });
$('#btnConfirmJoin').addEventListener('click', () => {
  const code = roomCodeInput.value.trim().toUpperCase();
  const errEl = $('#joinError');
  errEl.textContent = '';
  if (code.length !== 4) { errEl.textContent = 'Enter the 4-letter code from the Admin.'; return; }
  AudioFX.go();
  socket.emit('joinRoom', { code, name: profile.name, avatar: profile.avatar, playerId: profile.playerId }, (res) => {
    if (!res || !res.ok) { errEl.textContent = (res && res.message) || 'Could not join.'; return; }
    room = res.state;
    saveRoomSession(res.code);
    lobbyNameInput.value = profile.name;
    showScreen('lobby');
    renderLobby(room);
  });
});

/* ───────── lobby ───────── */
const MODE_LABEL = { classic: '⚔️ Classic', survival: '💀 Survival', blitz: '⚡ Blitz' };

function renderLobby(state) {
  room = state;
  $('#lobbyCode').textContent = state.code;
  $('#lobbyModeChip').textContent = MODE_LABEL[state.mode] || state.mode;
  $('#lobbyCatChip').textContent = state.categoryLabel;
  $('#lobbyCountChip').textContent = `${state.questionCount} Q`;
  $('#lobbyPlayerCount').textContent = `${state.players.length}/${state.maxPlayers}`;

  const meId = profile.playerId;
  const me = state.players.find(p => p.id === meId);
  const amHost = !!(me && me.isHost);
  $$('.host-only').forEach(el => { el.hidden = !amHost; });
  $$('.non-host-only').forEach(el => { el.hidden = amHost; });

  const list = $('#playerList');
  list.innerHTML = '';
  for (const p of state.players) {
    const li = document.createElement('li');
    li.className = 'player-row' + (p.id === meId ? ' is-you' : '');
    li.innerHTML = `
      <div class="p-avatar">${escapeHtml(p.avatar)}</div>
      <span class="p-name">${escapeHtml(p.name)}</span>
      ${p.id === meId ? '<span class="p-tag">You</span>' : ''}
      ${p.isHost ? '<span class="p-host" title="Admin">👑</span>' : ''}
      ${amHost && p.id !== meId ? `<button class="kick-btn" data-player="${escapeHtml(p.id)}" title="Kick">✕</button>` : ''}`;
    const kickBtn = $('.kick-btn', li);
    if (kickBtn) kickBtn.addEventListener('click', () => {
      socket.emit('kickPlayer', { playerId: p.id }, (res) => { if (res && !res.ok) toast(res.message || 'Kick failed.'); });
    });
    list.appendChild(li);
  }
}

$('#btnCopyCode').addEventListener('click', async () => {
  const code = room ? room.code : '';
  try { await navigator.clipboard.writeText(code); toast('Code copied: ' + code); }
  catch { toast('Room code: ' + code); }
});
$('#btnLeaveLobby').addEventListener('click', () => { socket.emit('leaveRoom'); clearRoomSession(); showScreen('home'); });
$('#btnStartGame').addEventListener('click', () => {
  AudioFX.go();
  socket.emit('startGame', {}, (res) => { if (res && !res.ok) toast(res.message || 'Could not start.'); });
});

/* ───────── Power-Ups ───────── */
const POWERUP_META = {
  steal: { label: '💰 Steal 250', needsTarget: true, title: 'STEAL 250 POINTS', sub: 'Pick a fighter to steal from:' },
  bonus: { label: '✨ +250 Bonus', needsTarget: false },
  block: { label: '🚫 Block (1 Q)', needsTarget: true, title: 'BLOCK A FIGHTER', sub: 'They will be blocked on the next question:' },
  gamble: { label: '🎲 Save / Lose', needsTarget: false },
};

function renderPowerupBar() {
  const bar = $('#powerupBar');
  if (!room) { bar.hidden = true; return; }
  const me = room.players.find(p => p.id === profile.playerId);
  const list = (me && me.powerups) || [];
  if (!list.length) { bar.hidden = true; bar.innerHTML = ''; return; }
  bar.hidden = false;
  bar.innerHTML = '';
  list.forEach((type) => {
    const meta = POWERUP_META[type];
    if (!meta) return;
    const b = document.createElement('button');
    b.className = 'powerup-btn';
    b.textContent = meta.label;
    b.addEventListener('click', () => {
      AudioFX.click();
      if (meta.needsTarget) openTargetModal(type, meta);
      else triggerPowerup(type, null);
    });
    bar.appendChild(b);
  });
}

function openTargetModal(type, meta) {
  $('#targetModalTitle').textContent = meta.title;
  $('#targetModalSub').textContent = meta.sub;
  const list = $('#targetList');
  list.innerHTML = '';
  const others = (room && room.players || []).filter(p => p.id !== profile.playerId && p.connected);
  if (!others.length) {
    list.innerHTML = '<p class="panel-sub">No other players available.</p>';
  } else {
    others.forEach(p => {
      const b = document.createElement('button');
      b.className = 'target-btn';
      b.innerHTML = `<span>${escapeHtml(p.avatar)} ${escapeHtml(p.name)}</span><span>${Number(p.score).toLocaleString()} pts</span>`;
      b.addEventListener('click', () => {
        $('#targetModal').hidden = true;
        triggerPowerup(type, p.id);
      });
      list.appendChild(b);
    });
  }
  $('#targetModal').hidden = false;
}
$('#btnCloseTarget').addEventListener('click', () => { $('#targetModal').hidden = true; });

function triggerPowerup(type, targetId) {
  socket.emit('usePowerup', { type, targetId }, (res) => {
    if (res && !res.ok) toast(res.message || 'Could not use power-up.');
    else if (res && res.newScore != null) $('#hudScore').textContent = Number(res.newScore).toLocaleString();
  });
}
socket.on('powerupEvent', (d) => { if (d && d.message) toast(d.message); });

/* ───────── game: question flow ───────── */
const LETTERS = ['A', 'B', 'C', 'D'];
const answersGrid = $('#answersGrid');
const revealPanel = $('#revealPanel');

function buildAnswerButtons(options) {
  answersGrid.innerHTML = '';
  options.forEach((opt, i) => {
    const b = document.createElement('button');
    b.className = 'answer-btn';
    b.dataset.index = i;
    b.innerHTML = `<span class="answer-shape">${LETTERS[i]}</span><span class="answer-text">${escapeHtml(opt)}</span><span class="answer-key">${LETTERS[i]}</span>`;
    b.addEventListener('click', () => submitAnswer(i));
    answersGrid.appendChild(b);
  });
}

function startTimer(durationMs, remainingMs) {
  stopTimer();
  questionDurationMs = durationMs;
  questionDeadline = Date.now() + (remainingMs ?? durationMs);
  lastTick = null;
  const fill = $('#timerFill');
  const num = $('#timerNumber');
  const tick = () => {
    const remain = Math.max(0, questionDeadline - Date.now());
    const frac = remain / questionDurationMs;
    fill.style.width = (frac * 100).toFixed(2) + '%';
    const secs = Math.ceil(remain / 1000);
    num.textContent = secs;
    num.classList.toggle('urgent', secs <= 5 && remain > 0);
    if (secs <= 5 && secs >= 1 && lastTick !== secs) { lastTick = secs; AudioFX.tick(); }
    if (remain > 0) timerRAF = requestAnimationFrame(tick);
    else { fill.style.width = '0%'; num.textContent = '0'; }
  };
  tick();
}
function stopTimer() { if (timerRAF) cancelAnimationFrame(timerRAF); timerRAF = null; }

socket.on('gameStarting', (d) => {
  showScreen('game');
  hasAnswered = false; lastAck = null;
  $('#hudRoom').textContent = 'ROOM ' + (room ? room.code : '····');
  $('#hudScore').textContent = '0';
  $('#hudQuestion').textContent = '—/' + d.total;
  $('#hudProgressFill').style.width = '0%';
  $('#qCategory').textContent = d.mode === 'survival' ? 'SURVIVAL' : d.mode === 'blitz' ? 'BLITZ RUSH' : 'CLASSIC BATTLE';
  $('#qAlive').textContent = '';
  $('#questionText').textContent = 'Get ready…';
  $('#timerNumber').textContent = '';
  $('#timerFill').style.width = '100%';
  $('#answerStatus').textContent = '';
  answersGrid.innerHTML = '';
  $('#idAnswerBox').hidden = true;
  revealPanel.hidden = true;
  let n = Math.max(1, Math.round(d.countdown || 2));
  const cd = setInterval(() => {
    if (n <= 0) { clearInterval(cd); AudioFX.go(); return; }
    $('#questionText').textContent = n + '…';
    AudioFX.countdown();
    n -= 1;
  }, 750);
});

socket.on('question', (d) => {
  hasAnswered = false; lastAck = null;
  currentQType = d.type || 'mc';
  lastQuestionIndex = d.index; lastTotalQuestions = d.total;
  showScreen('game');
  $('#hudRoom').textContent = 'ROOM ' + (room ? room.code : '····');
  $('#hudQuestion').textContent = `Q ${d.index + 1}/${d.total}`;
  $('#hudProgressFill').style.width = `${(d.index / d.total) * 100}%`;
  $('#qCategory').textContent = d.categoryLabel || 'Reviewer';
  $('#qTypeBadge').textContent = d.type === 'id' ? 'IDENTIFICATION' : d.type === 'tf' ? 'TRUE / FALSE' : 'A / B / C / D';
  $('#qAlive').textContent = d.mode === 'survival' ? `💀 ${d.aliveCount} alive` : '';
  $('#qAlive').className = 'chip' + (d.mode === 'survival' ? ' red' : '');
  $('#questionText').textContent = d.text;
  $('#answerStatus').textContent = '';
  revealPanel.hidden = true;
  $('#revealCorrectText').hidden = true;

  const amMonitor = room && room.hostSocketId === socket.id;
  const amBlocked = (d.blockedIds || []).includes(profile.playerId);
  if (amMonitor) {
    answersGrid.innerHTML = '';
    $('#idAnswerBox').hidden = true;
    $('#powerupBar').hidden = true;
    $('#answerStatus').innerHTML = '<b>🛡️ Admin Monitor Mode</b> — You are monitoring this match.';
    hasAnswered = true;
  } else if (d.type === 'id') {
    answersGrid.innerHTML = '';
    $('#idAnswerBox').hidden = amBlocked;
    $('#idAnswerInput').value = '';
    $('#idAnswerInput').disabled = false;
    $('#btnSubmitId').disabled = false;
    if (!amBlocked) setTimeout(() => $('#idAnswerInput').focus(), 60);
  } else {
    $('#idAnswerBox').hidden = true;
    buildAnswerButtons(d.options);
    if (amBlocked) $$('.answer-btn', answersGrid).forEach(b => { b.disabled = true; b.classList.add('dimmed'); });
  }

  if (amBlocked && !amMonitor) {
    hasAnswered = true;
    $('#answerStatus').innerHTML = '<b>🚫 You were BLOCKED for this question!</b>';
  }
  if (!amMonitor) renderPowerupBar();
  startTimer(d.timeLimit * 1000, d.remainingMs);
});

function submitAnswer(choice) {
  if (hasAnswered) return;
  hasAnswered = true;
  AudioFX.lock();
  const btns = $$('.answer-btn', answersGrid);
  btns.forEach(b => { b.disabled = true; if (Number(b.dataset.index) !== choice) b.classList.add('dimmed'); });
  $('#answerStatus').textContent = '🔒 Locked in! Waiting for the others…';
  socket.emit('submitAnswer', { choice }, (res) => {
    lastAck = res || null;
    if (res && res.ok) {
      $('#hudScore').textContent = Number(res.newScore).toLocaleString();
      if (res.earnedPowerup) toast(`🎁 Earned power-up: ${POWERUP_META[res.earnedPowerup]?.label || res.earnedPowerup}!`);
      if (room && room.mode === 'survival' && !res.alive) {
        $('#answerStatus').innerHTML = '<b>💀 Eliminated!</b> You can spectate the rest…';
      }
    } else if (res && res.message) {
      $('#answerStatus').textContent = res.message;
    }
  });
}

$('#btnSubmitId').addEventListener('click', () => {
  if (hasAnswered) return;
  const text = $('#idAnswerInput').value.trim();
  if (!text) return toast('Type your answer first!');
  hasAnswered = true;
  AudioFX.lock();
  $('#idAnswerInput').disabled = true;
  $('#btnSubmitId').disabled = true;
  $('#answerStatus').textContent = '🔒 Locked in! Waiting for the others…';
  socket.emit('submitAnswer', { text }, (res) => {
    lastAck = res || null;
    if (res && res.ok) {
      $('#hudScore').textContent = Number(res.newScore).toLocaleString();
      if (res.earnedPowerup) toast(`🎁 Earned power-up: ${POWERUP_META[res.earnedPowerup]?.label || res.earnedPowerup}!`);
    } else if (res && res.message) {
      $('#answerStatus').textContent = res.message;
    }
  });
});
$('#idAnswerInput').addEventListener('keydown', e => { if (e.key === 'Enter') $('#btnSubmitId').click(); });

document.addEventListener('keydown', (e) => {
  if (currentScreen !== 'game' || hasAnswered || currentQType === 'id') return;
  const map = { '1': 0, '2': 1, '3': 2, '4': 3, a: 0, b: 1, c: 2, d: 3 };
  const k = e.key.toLowerCase();
  if (k in map) submitAnswer(map[k]);
});

socket.on('answerProgress', (d) => {
  if (hasAnswered) $('#answerStatus').innerHTML = `🔒 Locked in! <b>${d.answered}/${d.total}</b> answered`;
});

socket.on('reveal', (d) => {
  stopTimer();
  AudioFX.reveal();
  $('#hudProgressFill').style.width = `${((lastQuestionIndex + 1) / Math.max(1, lastTotalQuestions)) * 100}%`;

  const btns = $$('.answer-btn', answersGrid);
  btns.forEach(b => {
    const i = Number(b.dataset.index);
    b.disabled = true;
    if (i === d.correctIndex) b.classList.add('correct'); else b.classList.add('wrong');
  });

  if (d.type === 'id') {
    $('#revealCorrectText').hidden = false;
    $('#revealCorrectText').textContent = `✓ Correct Answer: ${d.correctText}`;
  } else {
    $('#revealCorrectText').hidden = true;
  }

  const banner = $('#revealBanner');
  if (lastAck && lastAck.ok) {
    if (lastAck.correct) { banner.textContent = `CORRECT!  +${lastAck.points} PTS`; banner.className = 'reveal-banner good'; AudioFX.correct(); }
    else if (room && room.mode === 'survival' && !lastAck.alive) { banner.textContent = '💀 ELIMINATED'; banner.className = 'reveal-banner bad'; AudioFX.wrong(); }
    else { banner.textContent = 'WRONG!'; banner.className = 'reveal-banner bad'; AudioFX.wrong(); }
  } else if (lastAck === null) {
    banner.textContent = "TIME'S UP!"; banner.className = 'reveal-banner neutral';
  } else {
    banner.textContent = lastAck.message || 'Too bad!'; banner.className = 'reveal-banner neutral';
  }

  // distribution bars
  const dist = $('#distBars');
  dist.innerHTML = '';
  const total = Math.max(1, (d.distribution || []).reduce((a, b) => a + b, 0));
  (d.distribution || []).forEach((n, i) => {
    const row = document.createElement('div');
    row.className = 'dist-row'; row.dataset.i = i;
    row.innerHTML = `<span>${LETTERS[i]}</span><div class="dist-track"><div class="dist-fill" style="width:${(n / total) * 100}%"></div></div><span>${n}</span>`;
    dist.appendChild(row);
  });

  // mini leaders
  const leadersEl = $('#revealLeaders');
  leadersEl.innerHTML = '<div class="field-label" style="margin-top:0">Top fighters</div>';
  (d.leaders || []).slice(0, 5).forEach((p, i) => {
    const row = document.createElement('div');
    row.className = 'leader-row';
    row.innerHTML = `<span class="lr-rank">${i + 1}</span><span>${escapeHtml(p.avatar)} ${escapeHtml(p.name)}</span><span class="lr-score">${Number(p.score).toLocaleString()}</span>`;
    leadersEl.appendChild(row);
  });

  // show player names on what they chose
  const choicesEl = $('#revealChoices');
  choicesEl.innerHTML = '';
  const pc = d.playerChoices || {};
  if (d.type === 'id') {
    const list = pc.id || [];
    if (list.length) {
      const grp = document.createElement('div');
      grp.className = 'choice-group';
      grp.innerHTML = '<span class="choice-label">Answers:</span>' + list.map(x =>
        `<span class="choice-chip ${x.correct ? 'good' : ''}">${escapeHtml(x.avatar)} ${escapeHtml(x.name)}: "${escapeHtml(x.text)}"</span>`
      ).join('');
      choicesEl.appendChild(grp);
    }
  } else {
    Object.keys(pc).forEach(optIdx => {
      const list = pc[optIdx] || [];
      if (!list.length) return;
      const isRight = Number(optIdx) === d.correctIndex;
      const grp = document.createElement('div');
      grp.className = 'choice-group';
      grp.innerHTML = `<span class="choice-label">${LETTERS[optIdx]}:</span>` + list.map(x =>
        `<span class="choice-chip ${isRight ? 'good' : ''}">${escapeHtml(x.avatar)} ${escapeHtml(x.name)}</span>`
      ).join('');
      choicesEl.appendChild(grp);
    });
  }

  revealPanel.hidden = false;
});

/* ───────── Limited Practice Mode (5 Q) ───────── */
let pracDeck = [];
let pracIdx = 0;
let pracScore = 0;

function startPractice() {
  socket.emit('getPracticeQuestions', {}, (res) => {
    if (!res || !res.ok) return toast('Could not load practice questions.');
    pracDeck = res.questions;
    pracIdx = 0; pracScore = 0;
    showScreen('practice');
    renderPracticeQ();
  });
}

function renderPracticeQ() {
  const q = pracDeck[pracIdx];
  $('#pracQuestion').textContent = `Q ${pracIdx + 1}/${pracDeck.length}`;
  $('#pracProgressFill').style.width = `${(pracIdx / pracDeck.length) * 100}%`;
  $('#pracCategory').textContent = q.category.toUpperCase();
  $('#pracText').textContent = q.text;
  $('#pracStatus').textContent = '';
  $('#btnPracNext').hidden = true;

  const grid = $('#pracAnswers');
  grid.innerHTML = '';
  if (q.type === 'id') {
    $('#pracIdBox').hidden = false;
    $('#pracIdInput').value = '';
    $('#pracIdInput').disabled = false;
    $('#btnPracSubmitId').disabled = false;
  } else {
    $('#pracIdBox').hidden = true;
    q.options.forEach((opt, i) => {
      const b = document.createElement('button');
      b.className = 'answer-btn';
      b.innerHTML = `<span class="answer-shape">${LETTERS[i]}</span><span class="answer-text">${escapeHtml(opt)}</span>`;
      b.addEventListener('click', () => {
        $$('.answer-btn', grid).forEach((x, idx) => {
          x.disabled = true;
          if (idx === q.correct) x.classList.add('correct');
          else x.classList.add('wrong');
        });
        const ok = i === q.correct;
        if (ok) { pracScore++; AudioFX.correct(); $('#pracStatus').innerHTML = '<b style="color:#4ade80">✓ Correct!</b>'; }
        else { AudioFX.wrong(); $('#pracStatus').innerHTML = '<b style="color:#ff8f8f">✕ Wrong!</b>'; }
        $('#btnPracNext').hidden = false;
      });
      grid.appendChild(b);
    });
  }
}

$('#btnPracSubmitId').addEventListener('click', () => {
  const q = pracDeck[pracIdx];
  const val = $('#pracIdInput').value.trim().toLowerCase();
  if (!val) return;
  $('#pracIdInput').disabled = true;
  $('#btnPracSubmitId').disabled = true;
  const ok = (q.accepted || []).some(a => a.toLowerCase() === val);
  if (ok) { pracScore++; AudioFX.correct(); $('#pracStatus').innerHTML = `<b style="color:#4ade80">✓ Correct! (${escapeHtml(q.correctText)})</b>`; }
  else { AudioFX.wrong(); $('#pracStatus').innerHTML = `<b style="color:#ff8f8f">✕ Answer: ${escapeHtml(q.correctText)}</b>`; }
  $('#btnPracNext').hidden = false;
});

$('#btnPracNext').addEventListener('click', () => {
  pracIdx++;
  if (pracIdx >= pracDeck.length) {
    toast(`Practice finished! Score: ${pracScore}/${pracDeck.length}`);
    showScreen('home');
  } else {
    renderPracticeQ();
  }
});
$('#btnExitPractice').addEventListener('click', () => showScreen('home'));

/* ───────── podium ───────── */
let lastPodiumData = [];
function renderPodium(data) {
  lastPodiumData = data.podium || [];
  const twistEl = $('#plotTwistBanner');
  if (twistEl) {
    if (data.plotTwist) {
      twistEl.textContent = data.plotTwist;
      twistEl.hidden = false;
    } else {
      twistEl.hidden = true;
    }
  }
  const podium = data.podium || [];
  const stage = $('#podiumStage');
  stage.innerHTML = '';
  const top3 = podium.slice(0, 3);
  const order = [top3[1], top3[0], top3[2]];
  const cls = ['second', 'first', 'third'];
  order.forEach((p, i) => {
    const slot = document.createElement('div');
    if (!p) { slot.className = 'podium-slot ' + cls[i]; slot.innerHTML = '<div class="podium-block">' + (i === 1 ? '1' : i === 0 ? '2' : '3') + '</div>'; stage.appendChild(slot); return; }
    slot.className = 'podium-slot ' + cls[i];
    slot.innerHTML = `
      ${cls[i] === 'first' ? '<div class="podium-crown">👑</div>' : ''}
      <div class="podium-avatar">${escapeHtml(p.avatar)}</div>
      <div class="podium-name">${escapeHtml(p.name)}</div>
      <div class="podium-score">${Number(p.score).toLocaleString()} pts</div>
      <div class="podium-block">${cls[i] === 'first' ? '1' : cls[i] === 'second' ? '2' : '3'}</div>`;
    stage.appendChild(slot);
  });

  const full = $('#podiumFull');
  full.innerHTML = '';
  podium.forEach((p) => {
    const row = document.createElement('div');
    row.className = 'podium-row' + (p.id === profile.playerId ? ' is-you' : '');
    row.innerHTML = `<span class="pr-pos">#${p.position}</span><span>${escapeHtml(p.avatar)} ${escapeHtml(p.name)}${p.id === profile.playerId ? ' (you)' : ''}</span><span class="pr-score">${Number(p.score).toLocaleString()}</span>`;
    full.appendChild(row);
  });

  const me = podium.find(p => p.id === profile.playerId);
  const note = $('#podiumRankNote');
  if (me && me.globalRank) {
    note.innerHTML = `You finished <b>#${me.position}</b> in this room · Global rank <b>#${me.globalRank}</b> with <b>${Number(me.totalPoints).toLocaleString()}</b> total points`;
  } else {
    note.textContent = me ? `You finished #${me.position} in this room.` : '';
  }

  const iAmHost = room && room.hostSocketId === socket.id;
  $$('#screen-podium .host-only').forEach(el => { el.hidden = !iAmHost; });

  launchConfetti();
  AudioFX.fanfare();
}

socket.on('gameOver', (data) => {
  stopTimer();
  showScreen('podium');
  renderPodium(data);
  refreshMyStats();
});
$('#btnPlayAgain').addEventListener('click', () => {
  AudioFX.click();
  socket.emit('backToLobby', {}, () => {
    socket.emit('startGame', {}, (res) => { if (res && !res.ok) toast(res.message || 'Could not restart.'); });
  });
});

$('#btnExportCsv').addEventListener('click', () => {
  if (!lastPodiumData.length) return toast('No results to export.');
  const rows = [['Rank', 'Name', 'Score', 'Correct']];
  lastPodiumData.forEach(p => rows.push([p.position, `"${String(p.name).replace(/"/g, '""')}"`, p.score, p.correctCount || 0]));
  const csv = rows.map(r => r.join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `rizal-quiz-results-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
});

/* ───────── confetti ───────── */
function launchConfetti() {
  const canvas = $('#confettiCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  canvas.width = window.innerWidth; canvas.height = window.innerHeight;
  if (confettiRAF) cancelAnimationFrame(confettiRAF);
  const COLORS = ['#e8c15a', '#ffe27a', '#f3e7c8', '#e21b3c', '#26890c', '#1368ce', '#ffffff'];
  const pieces = Array.from({ length: 160 }, () => ({
    x: Math.random() * canvas.width,
    y: -40 - Math.random() * canvas.height * 0.6,
    w: 5 + Math.random() * 8,
    h: 8 + Math.random() * 14,
    vy: 1.6 + Math.random() * 2.4,
    vx: (Math.random() - 0.5) * 1.6,
    rot: Math.random() * Math.PI,
    vr: (Math.random() - 0.5) * 0.12,
    sway: Math.random() * Math.PI * 2,
    color: COLORS[Math.floor(Math.random() * COLORS.length)],
  }));
  const start = performance.now();
  const frame = (t) => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (const p of pieces) {
      p.y += p.vy; p.x += p.vx + Math.sin(t / 380 + p.sway) * 0.7; p.rot += p.vr;
      if (p.y > canvas.height + 30) { p.y = -30; p.x = Math.random() * canvas.width; }
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
      ctx.fillStyle = p.color; ctx.globalAlpha = 0.92;
      ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      ctx.restore();
    }
    if (t - start < 6000) confettiRAF = requestAnimationFrame(frame);
    else ctx.clearRect(0, 0, canvas.width, canvas.height);
  };
  confettiRAF = requestAnimationFrame(frame);
}

/* ───────── leaderboard (with Admin Adjust) ───────── */
function openLeaderboard(isAdminView = false) {
  socket.emit('getLeaderboard', { playerId: profile.playerId }, (res) => {
    renderBoardRows(res, isAdminView);
    showScreen('leaderboard');
  });
}

function renderBoardRows(res, isAdminView) {
  const tbody = $('#boardTable tbody');
  tbody.innerHTML = '';
  $$('.admin-col').forEach(el => { el.hidden = !isAdminView; });
  const entries = (res && res.entries) || [];
  const medals = ['🥇', '🥈', '🥉'];
  if (!entries.length) {
    tbody.innerHTML = `<tr><td colspan="${isAdminView ? 7 : 6}" style="text-align:center;padding:30px;color:rgba(243,231,200,.6)">No battles fought yet — be the first to make history!</td></tr>`;
  }
  for (const e of entries) {
    const tr = document.createElement('tr');
    if (e.id === profile.playerId) tr.className = 'is-you';
    const rankCell = e.rank <= 3 ? `<span class="rank-medal">${medals[e.rank - 1]}</span>` : `#${e.rank}`;
    tr.innerHTML = `
      <td>${rankCell}</td>
      <td><span class="b-avatar">${escapeHtml(e.avatar)}</span>${escapeHtml(e.name)}</td>
      <td>${e.wins}</td><td>${e.gamesPlayed}</td>
      <td>${Number(e.bestScore).toLocaleString()}</td>
      <td>${Number(e.totalPoints).toLocaleString()}</td>
      ${isAdminView ? `<td><div class="admin-adj-btns">
        <button class="adj-btn" data-d="100">+100</button>
        <button class="adj-btn" data-d="-100">-100</button>
        <button class="adj-btn del" data-del="1">✕</button>
      </div></td>` : ''}`;
    if (isAdminView) {
      $$('.adj-btn[data-d]', tr).forEach(b => b.addEventListener('click', () => {
        socket.emit('adminAdjustScore', { adminPin, playerId: e.id, delta: Number(b.dataset.d) }, (r) => {
          if (r && r.ok) renderBoardRows(r, true);
          else toast(r?.message || 'Error');
        });
      }));
      const delBtn = $('.adj-btn[data-del]', tr);
      if (delBtn) delBtn.addEventListener('click', () => {
        socket.emit('adminDeletePlayer', { adminPin, playerId: e.id }, (r) => {
          if (r && r.ok) renderBoardRows(r, true);
          else toast(r?.message || 'Error');
        });
      });
    }
    tbody.appendChild(tr);
  }
  $('#boardFootnote').textContent = `${res && res.totalPlayers ? res.totalPlayers : 0} fighters have made history · ranked by total battle points`;
}

/* ───────── room state & rejoin ───────── */
socket.on('roomState', (state) => {
  room = state;
  if (currentScreen === 'lobby') renderLobby(state);
  if (currentScreen === 'game') renderPowerupBar();
  const me = state.players && state.players.find(p => p.id === profile.playerId);
  if (me) $('#hudScore').textContent = Number(me.score).toLocaleString();
  const iAmHost = state.hostSocketId === socket.id;
  $$('#screen-podium .host-only').forEach(el => { el.hidden = !iAmHost; });
});

socket.on('roomClosed', (d) => { toast((d && d.reason) || 'The room was closed.'); clearRoomSession(); showScreen('home'); });
socket.on('kicked', (d) => { toast((d && d.reason) || 'You were removed from the room.'); clearRoomSession(); showScreen('home'); });

socket.on('connect', () => {
  const session = getRoomSession();
  if (session && session.code && session.playerId === profile.playerId) {
    socket.emit('rejoinRoom', { code: session.code, playerId: profile.playerId }, (res) => {
      if (res && res.ok) {
        room = res.state;
        lobbyNameInput.value = profile.name;
        if (room.state === 'lobby') { showScreen('lobby'); renderLobby(room); }
        else if (room.state === 'question' || room.state === 'reveal') { showScreen('game'); }
        else if (room.state === 'podium') { showScreen('podium'); }
        toast('Reconnected to room ' + room.code);
      } else {
        clearRoomSession();
      }
    });
  }
  refreshMyStats();
});

/* ───────── Published Games (Student Dashboard) ───────── */
function loadPublishedGames() {
  socket.emit('getPublishedGames', {}, (res) => {
    if (res && res.ok) renderPublishedGames(res.games || []);
  });
}
function renderPublishedGames(games) {
  const box = $('#publishedGamesBox');
  const list = $('#publishedGamesList');
  if (!box || !list) return;
  if (!games.length) { box.hidden = true; return; }
  box.hidden = false;
  list.innerHTML = '';
  games.forEach(g => {
    const row = document.createElement('div');
    row.className = 'published-item';
    row.innerHTML = `
      <div>
        <b>${escapeHtml(g.title)}</b>
        <small>${escapeHtml(g.categoryLabel)} · ${g.questionCount === 'all' ? 'Whole Game' : g.questionCount + ' Q'} · ${escapeHtml(g.mode)}</small>
      </div>
      <button class="ghost-btn small" data-play="${escapeHtml(g.id)}">▶ Play</button>
    `;
    $('button[data-play]', row).addEventListener('click', () => {
      AudioFX.click();
      // Start a practice/published run with those settings
      startPractice();
    });
    list.appendChild(row);
  });
}
socket.on('publishedGamesUpdated', (d) => renderPublishedGames((d && d.games) || []));

$('#btnPublishGame').addEventListener('click', () => {
  const title = $('#inputPublishTitle').value.trim() || 'Rizal Quiz';
  socket.emit('adminPublishGame', {
    adminPin,
    title,
    mode: selectedMode,
    category: $('#selectCategory').value,
    questionCount: selectedCount,
  }, (res) => {
    if (res && res.ok) {
      toast('📢 Published "' + res.game.title + '" to Student Dashboard!');
      $('#inputPublishTitle').value = '';
      showScreen('home');
    } else {
      toast(res?.message || 'Could not publish.');
    }
  });
});

/* ───────── Admin Live Monitor ───────── */
socket.on('adminMonitorUpdate', (d) => {
  const panel = $('#adminMonitorPanel');
  if (!panel) return;
  panel.hidden = false;
  const ansText = d.type === 'id'
    ? d.correctText
    : `${LETTERS[d.correctIndex]} — ${d.correctText}`;
  $('#monitorAnswer').textContent = `✓ Correct Answer: ${ansText}`;

  const ansList = $('#monitorLiveAnswers');
  ansList.innerHTML = (d.answers || []).length
    ? d.answers.map(a => {
        const picked = d.type === 'id' ? `"${escapeHtml(a.textAnswer)}"` : (LETTERS[a.choice] || '—');
        return `<div>${escapeHtml(a.avatar)} <b>${escapeHtml(a.name)}</b>: ${picked} ${a.correct ? '<span style="color:#4ade80">✓</span>' : '<span style="color:#ff8f8f">✕</span>'}</div>`;
      }).join('')
    : '<div style="opacity:.6">Waiting for students to answer…</div>';

  const leadList = $('#monitorLiveLeaders');
  leadList.innerHTML = (d.leaders || []).map((l, i) =>
    `<div>#${i + 1} ${escapeHtml(l.avatar)} <b>${escapeHtml(l.name)}</b> — ${Number(l.score).toLocaleString()} pts</div>`
  ).join('');
});

/* ───────── boot ───────── */
inputName.value = profile.name;
lobbyNameInput.value = profile.name;
renderAvatarGrid();
showScreen('home');
refreshMyStats();
loadPublishedGames();
