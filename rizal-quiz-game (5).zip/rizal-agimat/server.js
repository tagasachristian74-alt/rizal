/**
 * RIZAL: THE FINAL JOURNEY — Quiz Battle
 * Real-time multiplayer Kahoot-style quiz server.
 *
 * Features:
 * - Admin vs Student separation (Admin PIN required to create rooms & adjust rankings)
 * - Limited Practice Mode for students (5 questions, no ranking)
 * - Whole Game mode (all questions) + 10/15/20
 * - Mixed question types: Multiple Choice (A/B/C/D), True/False, Identification
 * - Power-ups: Steal Points, Bonus +250, Block Player (1 Q), Save/Lose Gamble
 * - Reveal shows player names on their chosen answers
 * - Persistent server-side ranking in data/db.json
 */

const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { Server } = require('socket.io');
const { QUESTIONS, CATEGORIES } = require('./questions');

const PORT = process.env.PORT || 3000;
const ADMIN_PIN = process.env.ADMIN_PIN || '2007Forge';
const MAX_PLAYERS = 16;
const DB_PATH = path.join(__dirname, 'data', 'db.json');

const QUESTION_TIME = { classic: 15, survival: 15, blitz: 10 };
const REVEAL_MS = 5500;
const COUNTDOWN_MS = 2600;

// ───────────────────────── Persistent stats store ─────────────────────────

function loadDb() {
  try {
    const raw = fs.readFileSync(DB_PATH, 'utf8');
    const db = JSON.parse(raw);
    if (!db.players) db.players = {};
    if (!db.publishedGames) db.publishedGames = [];
    return db;
  } catch {
    return { players: {}, publishedGames: [] };
  }
}

function saveDb(db) {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  const tmp = DB_PATH + '.tmp-' + process.pid;
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DB_PATH);
}

let db = loadDb();

function sanitizeName(name) {
  const cleaned = String(name || '')
    .replace(/[<>&"'`]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 16);
  return cleaned.length >= 2 ? cleaned : 'Rizalista';
}

function sanitizeAvatar(a) {
  const s = String(a || '').trim();
  if (!s || s.length > 8) return '🪶';
  return s;
}

function normalizeAnswer(str) {
  return String(str || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function recordGameResults(players) {
  const updated = {};
  for (const p of players) {
    if (!p.playerId) continue;
    const key = String(p.playerId).slice(0, 64);
    const prev = db.players[key] || {
      id: key, name: p.name, avatar: p.avatar,
      totalPoints: 0, gamesPlayed: 0, wins: 0, bestScore: 0, totalCorrect: 0,
    };
    prev.name = p.name;
    prev.avatar = p.avatar;
    prev.totalPoints = Math.max(0, prev.totalPoints + p.score);
    prev.gamesPlayed += 1;
    prev.wins += p.won ? 1 : 0;
    prev.bestScore = Math.max(prev.bestScore || 0, p.score);
    prev.totalCorrect = (prev.totalCorrect || 0) + (p.correctCount || 0);
    prev.updatedAt = new Date().toISOString();
    db.players[key] = prev;
    updated[key] = prev;
  }
  saveDb(db);
  return updated;
}

function leaderboard(limit = 20) {
  const rows = Object.values(db.players)
    .sort((a, b) =>
      (b.totalPoints - a.totalPoints) ||
      (b.wins - a.wins) ||
      (b.bestScore - a.bestScore) ||
      (b.gamesPlayed - a.gamesPlayed)
    );
  return rows.slice(0, limit).map((p, i) => ({
    rank: i + 1,
    id: p.id,
    name: p.name,
    avatar: p.avatar,
    totalPoints: p.totalPoints,
    wins: p.wins,
    gamesPlayed: p.gamesPlayed,
    bestScore: p.bestScore,
  }));
}

function playerRank(playerId) {
  const rows = Object.values(db.players)
    .sort((a, b) =>
      (b.totalPoints - a.totalPoints) ||
      (b.wins - a.wins) ||
      (b.bestScore - a.bestScore) ||
      (b.gamesPlayed - a.gamesPlayed)
    );
  const idx = rows.findIndex(p => p.id === playerId);
  if (idx === -1) return null;
  const p = rows[idx];
  return {
    rank: idx + 1,
    totalPlayers: rows.length,
    totalPoints: p.totalPoints,
    wins: p.wins,
    gamesPlayed: p.gamesPlayed,
    bestScore: p.bestScore,
    winRate: p.gamesPlayed ? Math.round((p.wins / p.gamesPlayed) * 100) : 0,
  };
}

// ───────────────────────── Express + Socket.IO ─────────────────────────

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] },
});

app.use(express.static(path.join(__dirname, 'public'), { maxAge: '1h' }));
app.get('/api/leaderboard', (_req, res) => res.json({ entries: leaderboard(20), totalPlayers: Object.keys(db.players).length }));
app.get('/api/categories', (_req, res) => res.json(CATEGORIES));
app.get('/healthz', (_req, res) => res.send('ok'));

// ───────────────────────── Room management ─────────────────────────

const rooms = new Map();
const socketRoom = new Map();

const CODE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
function makeRoomCode() {
  for (let attempt = 0; attempt < 200; attempt++) {
    let code = '';
    for (let i = 0; i < 4; i++) code += CODE_ALPHABET[crypto.randomInt(0, CODE_ALPHABET.length)];
    if (!rooms.has(code)) return code;
  }
  return crypto.randomBytes(3).toString('hex').toUpperCase().slice(0, 4);
}

function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = crypto.randomInt(0, i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function formatQuestion(q) {
  const type = q.type || 'mc';
  if (type === 'mc') {
    const order = shuffle([0, 1, 2, 3]);
    return {
      type: 'mc',
      text: q.q,
      options: order.map(i => q.o[i]),
      correct: order.indexOf(q.a),
      category: q.c,
    };
  }
  if (type === 'tf') {
    return {
      type: 'tf',
      text: q.q,
      options: ['True', 'False'],
      correct: q.a,
      category: q.c,
    };
  }
  // identification
  return {
    type: 'id',
    text: q.q,
    options: [],
    accepted: q.a,
    correctText: q.a[0],
    category: q.c,
  };
}

function buildDeck(category, count) {
  const pool = QUESTIONS.filter(q => category === 'all' || q.c === category);
  const limit = count === 'all' ? pool.length : Math.min(Number(count) || 15, pool.length);
  const picked = shuffle(pool).slice(0, limit);
  return picked.map(formatQuestion);
}

function publicPlayer(p) {
  return {
    id: p.playerId || p.socketId,
    socketId: p.socketId,
    name: p.name,
    avatar: p.avatar,
    score: p.score,
    streak: p.streak,
    correctCount: p.correctCount,
    alive: p.alive,
    connected: p.connected,
    isHost: p.isHost,
    blocked: p.blocked,
    powerups: p.powerups,
  };
}

function roomState(room) {
  return {
    code: room.code,
    mode: room.mode,
    category: room.category,
    categoryLabel: CATEGORIES[room.category] || room.category,
    questionCount: room.deck.length || (room.questionCount === 'all' ? QUESTIONS.filter(q => room.category === 'all' || q.c === room.category).length : room.questionCount),
    state: room.state,
    hostSocketId: room.hostSocketId,
    players: room.players.map(publicPlayer),
    maxPlayers: MAX_PLAYERS,
  };
}

function emitRoomState(room) {
  io.to(room.code).emit('roomState', roomState(room));
}

function activePlayers(room) {
  return room.players.filter(p => p.connected);
}

function answerablePlayers(room) {
  return room.players.filter(p => {
    if (p.isMonitor) return false;
    if (!p.connected) return false;
    if (room.mode === 'survival' && !p.alive) return false;
    if (p.blocked) return false;
    return true;
  });
}

function sortPodium(players) {
  return players.slice().sort((a, b) =>
    (b.score - a.score) ||
    (b.correctCount - a.correctCount) ||
    a.name.localeCompare(b.name)
  );
}

function pointsFor(mode, timeLeftMs, timeLimitMs, streak) {
  const frac = Math.max(0, Math.min(1, timeLeftMs / timeLimitMs));
  if (mode === 'blitz') return Math.round(800 + 700 * frac + Math.min(streak, 5) * 150);
  return Math.round(500 + 500 * frac + Math.min(streak, 5) * 100);
}

function clearRoomTimers(room) {
  if (room.timer) { clearTimeout(room.timer); room.timer = null; }
}

function destroyRoom(room, reason) {
  clearRoomTimers(room);
  if (reason) io.to(room.code).emit('roomClosed', { reason });
  for (const p of room.players) socketRoom.delete(p.socketId);
  rooms.delete(room.code);
}

function nextConnectedHost(room) {
  const next = room.players.find(p => p.connected);
  if (next) {
    room.players.forEach(p => { p.isHost = (p === next); });
    room.hostSocketId = next.socketId;
  }
  return next;
}

const POWERUP_TYPES = ['steal', 'bonus', 'block', 'gamble'];
function grantRandomPowerup(player) {
  const type = POWERUP_TYPES[crypto.randomInt(0, POWERUP_TYPES.length)];
  if (!player.powerups.includes(type)) {
    player.powerups.push(type);
    return type;
  }
  return null;
}

function startGame(room) {
  clearRoomTimers(room);
  room.deck = buildDeck(room.category, room.questionCount);
  room.index = -1;
  room.state = 'countdown';
  for (const p of room.players) {
    p.score = 0; p.streak = 0; p.correctCount = 0; p.alive = true;
    p.answered = false; p.choice = null; p.textAnswer = null;
    p.blocked = false; p.blockedNext = false; p.powerups = [];
  }
  emitRoomState(room);
  io.to(room.code).emit('gameStarting', { countdown: COUNTDOWN_MS / 1000, mode: room.mode, total: room.deck.length });
  room.timer = setTimeout(() => nextQuestion(room), COUNTDOWN_MS);
}

function nextQuestion(room) {
  clearRoomTimers(room);
  if (!rooms.has(room.code)) return;

  if (room.mode === 'survival' && room.index >= 0) {
    const aliveCount = room.players.filter(p => p.alive).length;
    if (aliveCount <= 1) return endGame(room, 'survival-resolved');
  }

  room.index += 1;
  if (room.index >= room.deck.length) return endGame(room, 'completed');

  const q = room.deck[room.index];
  room.state = 'question';
  room.questionStartedAt = Date.now();
  room.timeLimitMs = QUESTION_TIME[room.mode] * 1000;

  for (const p of room.players) {
    p.answered = false;
    p.choice = null;
    p.textAnswer = null;
    p.blocked = !!p.blockedNext;
    p.blockedNext = false;
    if (p.blocked) p.answered = true;
  }

  const payload = {
    index: room.index,
    total: room.deck.length,
    type: q.type,
    text: q.text,
    options: q.options,
    category: q.category,
    categoryLabel: CATEGORIES[q.category] || q.category,
    timeLimit: QUESTION_TIME[room.mode],
    mode: room.mode,
    aliveCount: room.players.filter(p => p.alive).length,
    blockedIds: room.players.filter(p => p.blocked).map(p => p.playerId),
  };
  io.to(room.code).emit('question', payload);
  if (room.hostSocketId) {
    io.to(room.hostSocketId).emit('adminMonitorUpdate', {
      index: room.index,
      total: room.deck.length,
      type: q.type,
      text: q.text,
      options: q.options,
      correctIndex: q.correct,
      correctText: q.correctText || (q.options ? q.options[q.correct] : ''),
      answers: [],
      leaders: sortPodium(room.players.filter(p => !p.isMonitor)).slice(0, 10).map(p => ({
        name: p.name, avatar: p.avatar, score: p.score,
      })),
    });
  }
  emitRoomState(room);

  // If everyone is blocked (edge case), reveal after 2s
  if (answerablePlayers(room).length === 0) {
    room.timer = setTimeout(() => reveal(room), 2000);
  } else {
    room.timer = setTimeout(() => reveal(room), room.timeLimitMs + 250);
  }
}

function reveal(room) {
  clearRoomTimers(room);
  if (room.state !== 'question') return;
  room.state = 'reveal';

  const q = room.deck[room.index];
  const distribution = q.type === 'tf' ? [0, 0] : q.type === 'mc' ? [0, 0, 0, 0] : [];
  const playerChoices = {}; // optionIndex -> [{ name, avatar }] or 'text' -> [{ name, avatar, text, correct }]

  for (const p of room.players) {
    if (q.type === 'id') {
      if (p.textAnswer !== null) {
        if (!playerChoices.id) playerChoices.id = [];
        playerChoices.id.push({
          name: p.name,
          avatar: p.avatar,
          text: p.textAnswer,
          correct: p.lastCorrect,
        });
      }
    } else if (p.choice != null) {
      distribution[p.choice] = (distribution[p.choice] || 0) + 1;
      if (!playerChoices[p.choice]) playerChoices[p.choice] = [];
      playerChoices[p.choice].push({ name: p.name, avatar: p.avatar });
    }
  }

  const leaders = sortPodium(room.players).slice(0, 5).map(p => ({
    name: p.name, avatar: p.avatar, score: p.score, streak: p.streak, alive: p.alive, id: p.playerId || p.socketId,
  }));

  io.to(room.code).emit('reveal', {
    index: room.index,
    type: q.type,
    correctIndex: q.correct,
    correctText: q.correctText || (q.options ? q.options[q.correct] : ''),
    distribution,
    playerChoices,
    leaders,
    aliveCount: room.players.filter(p => p.alive).length,
  });
  emitRoomState(room);
  room.timer = setTimeout(() => nextQuestion(room), REVEAL_MS);
}

function endGame(room, reason) {
  clearRoomTimers(room);
  if (room.state === 'podium') return;
  room.state = 'podium';

  const ranked = sortPodium(room.players.filter(p => !p.isMonitor));
  const topScore = ranked.length ? ranked[0].score : 0;
  for (const p of room.players) p.won = !p.isMonitor && p.score === topScore && topScore > 0;

  // ── PLOT TWIST AT THE END ──
  let plotTwist = null;
  if (ranked.length >= 2) {
    const twistRoll = crypto.randomInt(0, 4);
    if (twistRoll === 0) {
      const top = ranked[0];
      const second = ranked[1];
      const amt = Math.min(200, top.score);
      top.score -= amt;
      second.score += amt;
      plotTwist = `🔄 THE FINAL REVERSAL! ${top.name} gave ${amt} pts to ${second.name}!`;
    } else if (twistRoll === 1) {
      const mostCorrect = ranked.slice().sort((a, b) => b.correctCount - a.correctCount)[0];
      mostCorrect.score += 500;
      plotTwist = `🎁 RIZAL'S BLESSING! ${mostCorrect.name} had the most correct answers and gained +500 pts!`;
    } else if (twistRoll === 2) {
      const last = ranked[ranked.length - 1];
      const first = ranked[0];
      const steal = Math.min(250, first.score);
      first.score -= steal;
      last.score += steal;
      plotTwist = `💀 THE BAGUMBAYAN TWIST! ${last.name} stole ${steal} pts from ${first.name} at the last second!`;
    } else {
      ranked.forEach(p => { p.score += p.correctCount * 50; });
      plotTwist = `⚡ DAWN SURGE! Every fighter gained +50 pts per correct answer!`;
    }
  }

  const finalRanked = sortPodium(room.players.filter(p => !p.isMonitor));
  const finalTop = finalRanked.length ? finalRanked[0].score : 0;
  for (const p of room.players) p.won = !p.isMonitor && p.score === finalTop && finalTop > 0;

  let updatedMap = {};
  try { updatedMap = recordGameResults(finalRanked); } catch (err) { console.error('DB save failed:', err); }

  const board = leaderboard(20);
  const podium = finalRanked.map((p, i) => {
    const key = p.playerId ? String(p.playerId).slice(0, 64) : null;
    const fresh = key ? updatedMap[key] : null;
    const rankInfo = key ? playerRank(key) : null;
    return {
      position: i + 1,
      id: p.playerId || p.socketId,
      name: p.name,
      avatar: p.avatar,
      score: p.score,
      correctCount: p.correctCount,
      won: !!p.won,
      totalPoints: fresh ? fresh.totalPoints : null,
      bestScore: fresh ? fresh.bestScore : null,
      globalRank: rankInfo ? rankInfo.rank : null,
    };
  });

  io.to(room.code).emit('gameOver', { reason, plotTwist, podium, leaderboard: board });
  emitRoomState(room);
}

// ───────────────────────── Socket handlers ─────────────────────────

io.on('connection', (socket) => {
  socket.on('adminVerify', (payload = {}, ack) => {
    const ok = String(payload.pin || '').trim() === ADMIN_PIN;
    if (typeof ack === 'function') ack({ ok });
  });

  socket.on('getPracticeQuestions', (_payload, ack) => {
    const picked = shuffle(QUESTIONS).slice(0, 5).map(formatQuestion);
    if (typeof ack === 'function') ack({ ok: true, questions: picked });
  });

  socket.on('getPublishedGames', (_payload, ack) => {
    if (typeof ack === 'function') ack({ ok: true, games: db.publishedGames || [] });
  });

  socket.on('adminPublishGame', (payload = {}, ack) => {
    if (String(payload.adminPin || '').trim() !== ADMIN_PIN) {
      return ack && ack({ ok: false, message: 'Invalid Admin PIN.' });
    }
    const title = String(payload.title || 'Rizal Quiz').trim().slice(0, 40) || 'Rizal Quiz';
    const mode = ['classic', 'survival', 'blitz'].includes(payload.mode) ? payload.mode : 'classic';
    const category = CATEGORIES[payload.category] ? payload.category : 'all';
    const questionCount = payload.questionCount === 'all' ? 'all' : (Number(payload.questionCount) || 15);
    const game = {
      id: crypto.randomUUID().slice(0, 8),
      title,
      mode,
      category,
      categoryLabel: CATEGORIES[category],
      questionCount,
      createdAt: new Date().toISOString(),
    };
    db.publishedGames = db.publishedGames || [];
    db.publishedGames.unshift(game);
    db.publishedGames = db.publishedGames.slice(0, 10);
    saveDb(db);
    io.emit('publishedGamesUpdated', { games: db.publishedGames });
    if (typeof ack === 'function') ack({ ok: true, game, games: db.publishedGames });
  });

  socket.on('adminDeletePublished', (payload = {}, ack) => {
    if (String(payload.adminPin || '').trim() !== ADMIN_PIN) {
      return ack && ack({ ok: false, message: 'Invalid Admin PIN.' });
    }
    db.publishedGames = (db.publishedGames || []).filter(g => g.id !== payload.id);
    saveDb(db);
    io.emit('publishedGamesUpdated', { games: db.publishedGames });
    if (typeof ack === 'function') ack({ ok: true, games: db.publishedGames });
  });

  socket.on('createRoom', (payload = {}, ack) => {
    try {
      if (String(payload.adminPin || '').trim() !== ADMIN_PIN) {
        return ack && ack({ ok: false, message: 'Invalid Admin PIN. Only the Admin can create a game.' });
      }
      const name = sanitizeName(payload.name);
      const avatar = sanitizeAvatar(payload.avatar);
      const mode = ['classic', 'survival', 'blitz'].includes(payload.mode) ? payload.mode : 'classic';
      const questionCount = payload.questionCount === 'all' ? 'all' : ([10, 15, 20, 50].includes(Number(payload.questionCount)) ? Number(payload.questionCount) : 50);
      const category = CATEGORIES[payload.category] ? payload.category : 'all';
      const playerId = String(payload.playerId || crypto.randomUUID()).slice(0, 64);

      const code = makeRoomCode();
      const room = {
        code, hostSocketId: socket.id, mode, questionCount, category,
        state: 'lobby', deck: [], index: -1, timer: null,
        players: [{
          socketId: socket.id, playerId, name, avatar,
          score: 0, streak: 0, correctCount: 0, alive: true,
          answered: false, choice: null, textAnswer: null, lastCorrect: false,
          connected: true, isHost: true, isMonitor: true, won: false,
          blocked: false, blockedNext: false, powerups: [],
        }],
      };
      rooms.set(code, room);
      socketRoom.set(socket.id, code);
      socket.join(code);
      if (typeof ack === 'function') ack({ ok: true, code, state: roomState(room) });
      emitRoomState(room);
    } catch (err) {
      console.error('createRoom error:', err);
      if (typeof ack === 'function') ack({ ok: false, message: 'Could not create the room.' });
    }
  });

  socket.on('joinRoom', (payload = {}, ack) => {
    try {
      const code = String(payload.code || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
      const room = rooms.get(code);
      if (!room) return ack && ack({ ok: false, message: 'Room not found. Check the code and try again.' });
      if (room.state !== 'lobby') return ack && ack({ ok: false, message: 'That game has already started. Wait for the next round!' });
      if (room.players.filter(p => p.connected).length >= MAX_PLAYERS) return ack && ack({ ok: false, message: `Room is full (max ${MAX_PLAYERS} players).` });

      const name = sanitizeName(payload.name);
      const avatar = sanitizeAvatar(payload.avatar);
      const playerId = String(payload.playerId || crypto.randomUUID()).slice(0, 64);

      room.players.push({
        socketId: socket.id, playerId, name, avatar,
        score: 0, streak: 0, correctCount: 0, alive: true,
        answered: false, choice: null, textAnswer: null, lastCorrect: false,
          connected: true, isHost: false, isMonitor: false, won: false,
        blocked: false, blockedNext: false, powerups: [],
      });
      socketRoom.set(socket.id, code);
      socket.join(code);
      if (typeof ack === 'function') ack({ ok: true, code, state: roomState(room) });
      emitRoomState(room);
    } catch (err) {
      console.error('joinRoom error:', err);
      if (typeof ack === 'function') ack({ ok: false, message: 'Could not join the room.' });
    }
  });

  socket.on('rejoinRoom', (payload = {}, ack) => {
    try {
      const code = String(payload.code || '').trim().toUpperCase();
      const room = rooms.get(code);
      const playerId = String(payload.playerId || '');
      if (!room) return ack && ack({ ok: false, message: 'That room no longer exists.' });
      const player = room.players.find(p => p.playerId === playerId);
      if (!player) return ack && ack({ ok: false, message: 'You are not part of that room.' });

      socketRoom.delete(player.socketId);
      player.socketId = socket.id;
      player.connected = true;
      socketRoom.set(socket.id, code);
      socket.join(code);

      const state = roomState(room);
      if (typeof ack === 'function') ack({ ok: true, code, state });
      emitRoomState(room);

      if (room.state === 'question') {
        const q = room.deck[room.index];
        const elapsed = Date.now() - room.questionStartedAt;
        socket.emit('question', {
          index: room.index,
          total: room.deck.length,
          type: q.type,
          text: q.text,
          options: q.options,
          category: q.category,
          categoryLabel: CATEGORIES[q.category] || q.category,
          timeLimit: QUESTION_TIME[room.mode],
          remainingMs: Math.max(0, room.timeLimitMs - elapsed),
          mode: room.mode,
          aliveCount: room.players.filter(p => p.alive).length,
          blockedIds: room.players.filter(p => p.blocked).map(p => p.playerId),
          resumed: true,
        });
      }
    } catch (err) {
      console.error('rejoinRoom error:', err);
      if (typeof ack === 'function') ack({ ok: false, message: 'Rejoin failed.' });
    }
  });

  socket.on('updateProfile', (payload = {}) => {
    const code = socketRoom.get(socket.id);
    if (!code) return;
    const room = rooms.get(code);
    if (!room) return;
    const player = room.players.find(p => p.socketId === socket.id);
    if (!player) return;
    player.name = sanitizeName(payload.name || player.name);
    player.avatar = sanitizeAvatar(payload.avatar || player.avatar);
    emitRoomState(room);
  });

  socket.on('kickPlayer', (payload = {}, ack) => {
    const code = socketRoom.get(socket.id);
    const room = code && rooms.get(code);
    if (!room) return ack && ack({ ok: false, message: 'Room not found.' });
    if (room.hostSocketId !== socket.id) return ack && ack({ ok: false, message: 'Only the host can kick.' });
    const target = room.players.find(p => (p.playerId === payload.playerId) || (p.socketId === payload.socketId));
    if (!target || target.socketId === socket.id) return ack && ack({ ok: false, message: 'Cannot kick that player.' });
    const targetSocket = io.sockets.sockets.get(target.socketId);
    room.players = room.players.filter(p => p !== target);
    socketRoom.delete(target.socketId);
    if (targetSocket) {
      targetSocket.leave(room.code);
      targetSocket.emit('kicked', { reason: 'The Admin removed you from the room.' });
    }
    emitRoomState(room);
    if (typeof ack === 'function') ack({ ok: true });
  });

  socket.on('startGame', (_payload, ack) => {
    const code = socketRoom.get(socket.id);
    const room = code && rooms.get(code);
    if (!room) return ack && ack({ ok: false, message: 'Room not found.' });
    if (room.hostSocketId !== socket.id) return ack && ack({ ok: false, message: 'Only the Admin can start the game.' });
    if (!['lobby', 'podium'].includes(room.state)) return ack && ack({ ok: false, message: 'Game already in progress.' });
    if (activePlayers(room).length < 1) return ack && ack({ ok: false, message: 'Need at least one player.' });
    startGame(room);
    if (typeof ack === 'function') ack({ ok: true });
  });

  socket.on('backToLobby', (_payload, ack) => {
    const code = socketRoom.get(socket.id);
    const room = code && rooms.get(code);
    if (!room) return ack && ack({ ok: false, message: 'Room not found.' });
    if (room.hostSocketId !== socket.id) return ack && ack({ ok: false, message: 'Only the Admin can reset the room.' });
    clearRoomTimers(room);
    room.state = 'lobby';
    room.deck = []; room.index = -1;
    for (const p of room.players) {
      p.score = 0; p.streak = 0; p.correctCount = 0; p.alive = true;
      p.answered = false; p.choice = null; p.textAnswer = null; p.won = false;
      p.blocked = false; p.blockedNext = false; p.powerups = [];
    }
    emitRoomState(room);
    if (typeof ack === 'function') ack({ ok: true });
  });

  socket.on('submitAnswer', (payload = {}, ack) => {
    const code = socketRoom.get(socket.id);
    const room = code && rooms.get(code);
    if (!room || room.state !== 'question') return ack && ack({ ok: false, message: 'No question is live right now.' });
    const player = room.players.find(p => p.socketId === socket.id);
    if (!player) return ack && ack({ ok: false, message: 'You are not in this room.' });
    if (player.blocked) return ack && ack({ ok: false, message: 'You are BLOCKED for this question!' });
    if (player.answered) return ack && ack({ ok: false, message: 'Answer already locked in.' });
    if (room.mode === 'survival' && !player.alive) return ack && ack({ ok: false, message: 'You are eliminated. Hang on for the results!' });

    const q = room.deck[room.index];
    const elapsed = Date.now() - room.questionStartedAt;
    const timeLeft = Math.max(0, room.timeLimitMs - elapsed);
    let correct = false;

    if (q.type === 'id') {
      const rawText = String(payload.text || '').trim().slice(0, 60);
      if (!rawText) return ack && ack({ ok: false, message: 'Please type an answer.' });
      player.textAnswer = rawText;
      const norm = normalizeAnswer(rawText);
      correct = (q.accepted || []).some(ans => normalizeAnswer(ans) === norm);
    } else {
      const choice = Number(payload.choice);
      const maxOpt = q.type === 'tf' ? 1 : 3;
      if (!Number.isInteger(choice) || choice < 0 || choice > maxOpt) {
        return ack && ack({ ok: false, message: 'Invalid answer.' });
      }
      player.choice = choice;
      correct = choice === q.correct;
    }

    player.answered = true;
    player.lastCorrect = correct;

    let points = 0;
    let earnedPowerup = null;
    if (correct) {
      player.streak += 1;
      points = pointsFor(room.mode, timeLeft, room.timeLimitMs, player.streak);
      player.score += points;
      player.correctCount += 1;
      if (player.streak === 1 || player.streak % 2 === 0) {
        earnedPowerup = grantRandomPowerup(player);
      }
    } else {
      player.streak = 0;
      if (room.mode === 'survival') player.alive = false;
    }

    if (typeof ack === 'function') {
      ack({
        ok: true,
        correct,
        points,
        streak: player.streak,
        newScore: player.score,
        alive: player.alive,
        earnedPowerup,
      });
    }

    const remaining = answerablePlayers(room).filter(p => !p.answered).length;
    io.to(room.code).emit('answerProgress', {
      answered: answerablePlayers(room).length - remaining,
      total: answerablePlayers(room).length,
    });
    if (room.hostSocketId) {
      const liveAnswers = room.players.filter(p => p.answered && !p.blocked).map(p => ({
        name: p.name,
        avatar: p.avatar,
        choice: p.choice,
        textAnswer: p.textAnswer,
        correct: p.lastCorrect,
        score: p.score,
      }));
      io.to(room.hostSocketId).emit('adminMonitorUpdate', {
        index: room.index,
        total: room.deck.length,
        type: q.type,
        text: q.text,
        options: q.options,
        correctIndex: q.correct,
        correctText: q.correctText || (q.options ? q.options[q.correct] : ''),
        answers: liveAnswers,
        leaders: sortPodium(room.players).slice(0, 10).map(p => ({
          name: p.name, avatar: p.avatar, score: p.score,
        })),
      });
    }

    if (remaining === 0) reveal(room);
  });

  socket.on('usePowerup', (payload = {}, ack) => {
    const code = socketRoom.get(socket.id);
    const room = code && rooms.get(code);
    if (!room || !['question', 'reveal'].includes(room.state)) {
      return ack && ack({ ok: false, message: 'Power-ups can only be used during a match.' });
    }
    const player = room.players.find(p => p.socketId === socket.id);
    if (!player) return ack && ack({ ok: false, message: 'Player not found.' });
    const type = String(payload.type || '');
    const idx = player.powerups.indexOf(type);
    if (idx === -1) return ack && ack({ ok: false, message: 'You do not have that power-up.' });

    player.powerups.splice(idx, 1);
    let msg = '';

    if (type === 'bonus') {
      player.score += 250;
      msg = `${player.avatar} ${player.name} used ✨ Bonus (+250 pts)!`;
    } else if (type === 'gamble') {
      const win = crypto.randomInt(0, 2) === 1;
      if (win) {
        player.score += 400;
        if (room.mode === 'survival' && !player.alive) player.alive = true;
        msg = `${player.avatar} ${player.name} gambled SAVE/LOSE and WON (+400 pts)!`;
      } else {
        player.score = Math.max(0, player.score - 200);
        msg = `${player.avatar} ${player.name} gambled SAVE/LOSE and LOST (-200 pts)!`;
      }
    } else if (type === 'steal') {
      const target = room.players.find(p => p.playerId === payload.targetId && p !== player);
      if (!target) {
        player.powerups.push(type);
        return ack && ack({ ok: false, message: 'Pick a valid player to steal from.' });
      }
      const stolen = Math.min(target.score, 250);
      target.score -= stolen;
      player.score += stolen;
      msg = `${player.avatar} ${player.name} stole 💰 ${stolen} pts from ${target.name}!`;
    } else if (type === 'block') {
      const target = room.players.find(p => p.playerId === payload.targetId && p !== player);
      if (!target) {
        player.powerups.push(type);
        return ack && ack({ ok: false, message: 'Pick a valid player to block.' });
      }
      target.blockedNext = true;
      msg = `${player.avatar} ${player.name} 🚫 BLOCKED ${target.name} for the next question!`;
    }

    io.to(room.code).emit('powerupEvent', { message: msg, by: player.playerId, type });
    emitRoomState(room);
    if (typeof ack === 'function') ack({ ok: true, message: msg, newScore: player.score });
  });

  socket.on('leaveRoom', () => {
    const code = socketRoom.get(socket.id);
    const room = code && rooms.get(code);
    if (!room) return;
    removePlayerFromRoom(room, socket.id, 'left');
  });

  socket.on('getLeaderboard', (payload = {}, ack) => {
    const out = { entries: leaderboard(20), totalPlayers: Object.keys(db.players).length };
    if (payload && payload.playerId) {
      out.you = playerRank(String(payload.playerId).slice(0, 64));
    }
    if (typeof ack === 'function') ack(out); else socket.emit('leaderboard', out);
  });

  // ───────── Admin Ranking Adjustments ─────────
  socket.on('adminAdjustScore', (payload = {}, ack) => {
    if (String(payload.adminPin || '').trim() !== ADMIN_PIN) {
      return ack && ack({ ok: false, message: 'Invalid Admin PIN.' });
    }
    const id = String(payload.playerId || '');
    const delta = Number(payload.delta || 0);
    if (!db.players[id]) return ack && ack({ ok: false, message: 'Player not found in ranking.' });
    db.players[id].totalPoints = Math.max(0, (db.players[id].totalPoints || 0) + delta);
    saveDb(db);
    if (typeof ack === 'function') ack({ ok: true, entries: leaderboard(20), totalPlayers: Object.keys(db.players).length });
  });

  socket.on('adminDeletePlayer', (payload = {}, ack) => {
    if (String(payload.adminPin || '').trim() !== ADMIN_PIN) {
      return ack && ack({ ok: false, message: 'Invalid Admin PIN.' });
    }
    const id = String(payload.playerId || '');
    delete db.players[id];
    saveDb(db);
    if (typeof ack === 'function') ack({ ok: true, entries: leaderboard(20), totalPlayers: Object.keys(db.players).length });
  });

  socket.on('disconnect', () => {
    const code = socketRoom.get(socket.id);
    const room = code && rooms.get(code);
    if (!room) return;
    const player = room.players.find(p => p.socketId === socket.id);
    if (!player) return;

    if (room.state === 'lobby') {
      removePlayerFromRoom(room, socket.id, 'disconnected');
      return;
    }
    player.connected = false;
    player.answered = true;
    if (room.hostSocketId === socket.id) nextConnectedHost(room);

    const stillHere = room.players.some(p => p.connected);
    if (!stillHere) { destroyRoom(room, null); return; }

    if (room.state === 'question') {
      const remaining = answerablePlayers(room).filter(p => !p.answered).length;
      if (remaining === 0) reveal(room);
    }
    emitRoomState(room);
  });

  function removePlayerFromRoom(room, socketId, _why) {
    const wasHost = room.hostSocketId === socketId;
    room.players = room.players.filter(p => p.socketId !== socketId);
    socketRoom.delete(socketId);
    const s = io.sockets.sockets.get(socketId);
    if (s) s.leave(room.code);

    if (room.players.length === 0) { destroyRoom(room, null); return; }
    if (wasHost) nextConnectedHost(room);
    emitRoomState(room);
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n  ⚑  RIZAL: THE FINAL JOURNEY — Quiz Battle`);
  console.log(`     Listening on http://0.0.0.0:${PORT}`);
  console.log(`     Admin PIN: ${ADMIN_PIN}\n`);
});
